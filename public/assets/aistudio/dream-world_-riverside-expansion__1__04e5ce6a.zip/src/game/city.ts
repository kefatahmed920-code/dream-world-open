/**
 * Preserved Dhaka City Heritage & Dhaka Bridge — Dream World Phase 1
 * Preserves the historic Dhaka riverside city backdrop, iconic Dhaka bridge,
 * Ahsan Manzil inspired terracotta palace, rickshaw, and riverside promenade.
 * Also prepares the foundation markers on the far eastern vista for Phase 2.
 */

import * as THREE from 'three';
import { textureFactory } from './textures';

export class DhakaCityManager {
  public group: THREE.Group = new THREE.Group();

  constructor() {
    this.createDhakaBridge();
    this.createDhakaWaterfrontCity();
    this.createDhakaRickshaw();
    this.createPhase2FoundationalAbutments();
  }

  /**
   * Preserved Dhaka Bridge spanning the Buriganga river
   * Spans from North bank (Z: -24) to South bank (Z: +24) at X = -55
   */
  private createDhakaBridge() {
    const bridgeGroup = new THREE.Group();
    const bridgeX = -55;

    const concreteMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#8C8E8B'),
      roughness: 0.75,
      metalness: 0.1,
    });

    const steelMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#3A4B54'),
      roughness: 0.45,
      metalness: 0.7,
    });

    const asphaltMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#383938'),
      roughness: 0.85,
    });

    // Bridge deck length = 56m, width = 6.5m, thickness = 0.6m, elevated at Y = 5.2m
    const deckGeom = new THREE.BoxGeometry(6.5, 0.6, 56);
    const deck = new THREE.Mesh(deckGeom, asphaltMat);
    deck.position.set(bridgeX, 5.2, 0);
    deck.castShadow = true;
    deck.receiveShadow = true;
    bridgeGroup.add(deck);

    // Concrete river piers anchored deep into the riverbed
    const pierPositions = [-14, 0, 14];
    const pierGeom = new THREE.BoxGeometry(7.2, 10, 2.2);
    pierPositions.forEach((pz) => {
      const pier = new THREE.Mesh(pierGeom, concreteMat);
      pier.position.set(bridgeX, 0.5, pz);
      pier.castShadow = true;
      pier.receiveShadow = true;
      bridgeGroup.add(pier);
    });

    // Steel Arch Trusses on both sides of bridge deck
    [-3.1, 3.1].forEach((ox) => {
      // Arched curved truss
      const archCurve = new THREE.EllipseCurve(
        0, 0,
        25, 4.5,
        0, Math.PI,
        false,
        0
      );
      const points = archCurve.getPoints(24);
      const tubeGeom = new THREE.TubeGeometry(
        new THREE.CatmullRomCurve3(points.map(p => new THREE.Vector3(0, p.y, p.x))),
        24, 0.16, 8, false
      );
      const archMesh = new THREE.Mesh(tubeGeom, steelMat);
      archMesh.position.set(bridgeX + ox, 5.5, 0);
      archMesh.castShadow = true;
      bridgeGroup.add(archMesh);

      // Vertical suspension cables
      for (let cz = -20; cz <= 20; cz += 4) {
        const h = 4.2 * Math.cos((cz / 25) * (Math.PI / 2));
        const cableGeom = new THREE.CylinderGeometry(0.04, 0.04, Math.max(0.5, h));
        const cable = new THREE.Mesh(cableGeom, steelMat);
        cable.position.set(bridgeX + ox, 5.5 + h * 0.5, cz);
        bridgeGroup.add(cable);
      }

      // Safety Guard Railings
      const railGeom = new THREE.BoxGeometry(0.1, 1.1, 56);
      const rail = new THREE.Mesh(railGeom, steelMat);
      rail.position.set(bridgeX + ox, 5.85, 0);
      bridgeGroup.add(rail);
    });

    // Bridge Street Light Posts
    for (let lz = -22; lz <= 22; lz += 11) {
      const poleGeom = new THREE.CylinderGeometry(0.07, 0.09, 3.2);
      const lampArm = new THREE.Mesh(poleGeom, steelMat);
      lampArm.position.set(bridgeX - 3.2, 6.8, lz);
      bridgeGroup.add(lampArm);

      const lampHead = new THREE.Mesh(
        new THREE.BoxGeometry(0.3, 0.2, 0.4),
        new THREE.MeshStandardMaterial({ color: 0xFEE08B, emissive: 0xFFB300, emissiveIntensity: 0.6 })
      );
      lampHead.position.set(bridgeX - 2.9, 8.3, lz);
      bridgeGroup.add(lampHead);
    }

    this.group.add(bridgeGroup);
  }

  /**
   * Preserved Dhaka Waterfront City & Ahsan Manzil Palace
   * Positioned along North promenade (Z: -28 to -45, X: -50 to +20)
   */
  private createDhakaWaterfrontCity() {
    const cityGroup = new THREE.Group();
    const brickTex = textureFactory.getDhakaTerracottaBrickTexture();
    brickTex.repeat.set(2, 2);

    const palaceMat = new THREE.MeshStandardMaterial({
      map: brickTex,
      roughness: 0.78,
      metalness: 0.08,
    });

    const domeMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#3A7563'), // Aged copper verdigris dome
      roughness: 0.4,
      metalness: 0.6,
    });

    const trimMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#F0EAD6'), // Cream Mughal plaster trim
      roughness: 0.65,
    });

    // 1. Ahsan Manzil Palace Main Block
    const palaceX = -12;
    const palaceZ = -34;
    const palaceY = 4.0;

    const mainBlock = new THREE.Mesh(new THREE.BoxGeometry(26, 9, 14), palaceMat);
    mainBlock.position.set(palaceX, palaceY + 4.5, palaceZ);
    mainBlock.castShadow = true;
    mainBlock.receiveShadow = true;
    cityGroup.add(mainBlock);

    // Grand Iconic Octagonal Mughal Dome
    const drum = new THREE.Mesh(new THREE.CylinderGeometry(3.6, 3.8, 2.2, 8), trimMat);
    drum.position.set(palaceX, palaceY + 9 + 1.1, palaceZ);
    cityGroup.add(drum);

    const dome = new THREE.Mesh(new THREE.SphereGeometry(3.5, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2), domeMat);
    dome.position.set(palaceX, palaceY + 11.3, palaceZ);
    dome.castShadow = true;
    cityGroup.add(dome);

    const spire = new THREE.Mesh(new THREE.ConeGeometry(0.3, 2.5, 8), domeMat);
    spire.position.set(palaceX, palaceY + 14.8, palaceZ);
    cityGroup.add(spire);

    // Palace Front Portico Columns & Arches
    for (let col = -3; col <= 3; col++) {
      const column = new THREE.Mesh(new THREE.CylinderGeometry(0.3, 0.35, 7.5, 8), trimMat);
      column.position.set(palaceX + col * 3.4, palaceY + 3.75, palaceZ + 7.4);
      column.castShadow = true;
      cityGroup.add(column);
    }

    // 2. Flanking Heritage Riverside Buildings (Old Dhaka style shopfronts & residential flats)
    const buildingColors = ['#D18A57', '#C8A366', '#B75F48', '#8A6E59'];
    const buildingLocations: [number, number, number, number, number][] = [
      [-40, -32, 14, 11, 12],
      [-26, -32, 12, 10, 11],
      [6, -32, 13, 12, 12],
      [22, -32, 16, 10, 13],
      [40, -32, 15, 9, 12],
    ];

    buildingLocations.forEach(([bx, bz, bw, bh, bd], idx) => {
      const bMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(buildingColors[idx % buildingColors.length]),
        roughness: 0.82,
      });

      const bldg = new THREE.Mesh(new THREE.BoxGeometry(bw, bh, bd), bMat);
      bldg.position.set(bx, 4.0 + bh * 0.5, bz);
      bldg.castShadow = true;
      bldg.receiveShadow = true;
      cityGroup.add(bldg);

      // Windows and decorative balconies
      for (let floor = 1; floor <= Math.floor(bh / 3.5); floor++) {
        for (let w = -bw / 2 + 2; w <= bw / 2 - 2; w += 3.2) {
          const win = new THREE.Mesh(
            new THREE.BoxGeometry(1.2, 1.6, 0.1),
            new THREE.MeshStandardMaterial({ color: 0x1A2228, roughness: 0.3 })
          );
          win.position.set(bx + w, 4.0 + floor * 3.2, bz + bd * 0.5 + 0.05);
          cityGroup.add(win);
        }
      }
    });

    this.group.add(cityGroup);
  }

  /**
   * Traditional Dhaka Cycle Rickshaw
   * Parked on the promenade road overlooking the river
   */
  private createDhakaRickshaw() {
    const rickshaw = new THREE.Group();
    rickshaw.position.set(-6, 3.8, -17.5);
    rickshaw.rotation.y = 0.45;

    const chromeMat = new THREE.MeshStandardMaterial({ color: 0x8A8E90, metalness: 0.8, roughness: 0.3 });
    const hoodMat = new THREE.MeshStandardMaterial({ color: 0xD63031, roughness: 0.6 }); // Vibrant red hood
    const seatMat = new THREE.MeshStandardMaterial({ color: 0x1E8449, roughness: 0.7 }); // Green cushion
    const blackMat = new THREE.MeshStandardMaterial({ color: 0x222222, roughness: 0.9 });

    // 2 Large Rear Wheels
    const wheelGeom = new THREE.TorusGeometry(0.55, 0.04, 8, 16);
    [-0.55, 0.55].forEach((wx) => {
      const wheel = new THREE.Mesh(wheelGeom, blackMat);
      wheel.position.set(wx, 0.55, 0);
      rickshaw.add(wheel);
    });

    // Front Wheel
    const frontWheel = new THREE.Mesh(wheelGeom, blackMat);
    frontWheel.position.set(0, 0.55, 1.8);
    rickshaw.add(frontWheel);

    // Frame tubes
    const frame = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.1, 1.8), chromeMat);
    frame.position.set(0, 0.55, 0.9);
    rickshaw.add(frame);

    // Passenger Seat & Decorated Hood
    const seat = new THREE.Mesh(new THREE.BoxGeometry(1.0, 0.15, 0.6), seatMat);
    seat.position.set(0, 0.9, 0.1);
    rickshaw.add(seat);

    const hood = new THREE.Mesh(new THREE.CylinderGeometry(0.65, 0.65, 1.05, 12, 1, false, 0, Math.PI), hoodMat);
    hood.rotateZ(Math.PI / 2);
    hood.position.set(0, 1.45, 0.0);
    rickshaw.add(hood);

    // Handlebar & bell
    const handlebar = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.65), chromeMat);
    handlebar.rotateZ(Math.PI / 2);
    handlebar.position.set(0, 1.15, 1.7);
    rickshaw.add(handlebar);

    this.group.add(rickshaw);
  }

  /**
   * Phase 2 Preparation:
   * Foundation abutments on the far eastern river basin horizon (X: ~140 to 170).
   * Marks the beginning of the future traditional bridge and monumental Chinese gate
   * without creating the full city yet!
   */
  private createPhase2FoundationalAbutments() {
    const prepGroup = new THREE.Group();

    // River navigation channel marker buoys guiding boats along the channel
    const buoyMat = new THREE.MeshStandardMaterial({ color: 0xD35400, roughness: 0.3 });
    [45, 75, 105, 128].forEach((bx) => {
      const buoy = new THREE.Mesh(new THREE.ConeGeometry(0.35, 1.0, 8), buoyMat);
      buoy.position.set(bx, 0.4, 0);
      prepGroup.add(buoy);
    });

    this.group.add(prepGroup);
  }
}
