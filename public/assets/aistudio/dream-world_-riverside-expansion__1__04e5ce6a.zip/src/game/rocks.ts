/**
 * Premium Rock & Boulder System — Dream World Phase 1
 * Inspired by Where Winds Meet riverside geology:
 *  1. Layered flat slate rocks
 *  2. Irregular angular weathered boulders
 *  3. Small gravel and broken stones
 *  4. Moss-covered rocks partially submerged in river
 */

import * as THREE from 'three';
import { textureFactory } from './textures';
import { TerrainManager } from './terrain';

export class RockManager {
  public group: THREE.Group = new THREE.Group();
  public submergedRockFoamPositions: THREE.Vector3[] = [];

  constructor(private terrain: TerrainManager) {
    this.createLayeredSlateRocks();
    this.createAngularWeatheredBoulders();
    this.createRiverShorelineGravel();
    this.createMossySubmergedRocks();
  }

  /**
   * 1. Layered Flat Slate Rocks
   * Stepped, horizontal fissured stone slabs stacked along natural terraces and bank shelves
   */
  private createLayeredSlateRocks() {
    const slateTex = textureFactory.getSlateRockTexture();
    slateTex.repeat.set(1.5, 1.5);
    const slateMat = new THREE.MeshStandardMaterial({
      map: slateTex,
      roughness: 0.85,
      metalness: 0.05,
    });

    const locations: [number, number, number][] = [
      // Natural slate outcrops near the dock approach (East of dock)
      [26, -11, 2.2],
      [28.5, -9.5, 1.8],
      [34, -8, 2.0],
      [42, -7.5, 2.5],
      // South bank slate terraces
      [-15, 16, 2.4],
      [-5, 18, 2.2],
      [12, 19, 2.8],
      [25, 21, 2.6],
      // East river gorge cliffs
      [58, -12, 3.2],
      [75, -15, 3.8],
      [92, -18, 4.2],
      [62, 16, 3.5],
      [84, 18, 4.0],
      [110, 22, 4.5],
    ];

    locations.forEach(([x, z, scale]) => {
      const rockGroup = new THREE.Group();
      // Multi-layer stacked slabs
      const slabCount = 3 + Math.floor(Math.random() * 3);
      for (let s = 0; s < slabCount; s++) {
        const sw = (2.2 - s * 0.35) * scale * (0.8 + Math.random() * 0.4);
        const sd = (1.8 - s * 0.3) * scale * (0.8 + Math.random() * 0.4);
        const sh = 0.35 * scale;
        const slabGeom = new THREE.BoxGeometry(sw, sh, sd);
        const slab = new THREE.Mesh(slabGeom, slateMat);
        slab.position.set(
          (Math.random() - 0.5) * 0.3 * scale,
          s * sh * 0.9,
          (Math.random() - 0.5) * 0.3 * scale
        );
        slab.rotation.y = Math.random() * Math.PI;
        slab.rotation.z = (Math.random() - 0.5) * 0.08;
        slab.castShadow = true;
        slab.receiveShadow = true;
        rockGroup.add(slab);
      }

      const groundY = this.terrain.getElevationAt(x, z);
      rockGroup.position.set(x, groundY - 0.15, z);
      this.group.add(rockGroup);
    });
  }

  /**
   * 2. Irregular Angular Weathered Boulders
   * Faceted geometric boulders with randomized vertices, weathered corners
   */
  private createAngularWeatheredBoulders() {
    const slateTex = textureFactory.getSlateRockTexture();
    const boulderMat = new THREE.MeshStandardMaterial({
      map: slateTex,
      color: new THREE.Color('#7A7D79'),
      roughness: 0.9,
      metalness: 0.04,
      flatShading: true,
    });

    const boulderSpots: [number, number, number][] = [
      // Along West bank
      [-45, -12, 2.5],
      [-55, -14, 3.2],
      [-38, 14, 2.8],
      // Near dock bank transition
      [-8, -13, 1.8],
      [-12, -11, 2.0],
      // East gorge canyon entrance (where the unnatural mountain was opened!)
      [48, -10, 3.8],
      [52, 14, 4.2],
      [68, -8, 3.5],
      [72, 12, 3.6],
      [105, -14, 4.5],
      [120, 16, 5.0],
      [145, -12, 4.0],
      [150, 15, 4.8],
    ];

    boulderSpots.forEach(([x, z, scale]) => {
      // Procedural angular boulder from displaced Dodecahedron
      const geom = new THREE.DodecahedronGeometry(scale, 1);
      const pos = geom.attributes.position;
      for (let i = 0; i < pos.count; i++) {
        const v = new THREE.Vector3(pos.getX(i), pos.getY(i), pos.getZ(i));
        // Asymmetric angular noise
        const n = 1.0 + Math.sin(v.x * 2.5) * 0.2 + Math.cos(v.y * 3.0) * 0.25;
        v.multiplyScalar(n);
        pos.setXYZ(i, v.x, v.y, v.z);
      }
      geom.computeVertexNormals();

      const mesh = new THREE.Mesh(geom, boulderMat);
      const groundY = this.terrain.getElevationAt(x, z);
      // Embed partially into the ground so it feels solid and grounded
      mesh.position.set(x, groundY + scale * 0.45, z);
      mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, Math.random() * Math.PI);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.group.add(mesh);
    });
  }

  /**
   * 3. Small Gravel and Broken River Shoreline Stones
   * Clustered instanced broken gravel pebbles along water-earth transition
   */
  private createRiverShorelineGravel() {
    const gravelGeom = new THREE.DodecahedronGeometry(0.22, 0);
    const gravelMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#6E685C'),
      roughness: 0.95,
      flatShading: true,
    });

    const gravelCount = 80;
    const instancedGravel = new THREE.InstancedMesh(gravelGeom, gravelMat, gravelCount);
    const dummy = new THREE.Object3D();

    for (let i = 0; i < gravelCount; i++) {
      // Disperse along riverbanks where Y is between 0.1 and 1.2
      const isNorth = Math.random() > 0.5;
      const x = -60 + Math.random() * 190;
      const z = isNorth ? -12 - Math.random() * 5 : 12 + Math.random() * 6;
      const groundY = this.terrain.getElevationAt(x, z);

      dummy.position.set(x, groundY + 0.08, z);
      const scale = 0.5 + Math.random() * 1.4;
      dummy.scale.set(scale, scale * 0.6, scale * 0.8);
      dummy.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
      dummy.updateMatrix();
      instancedGravel.setMatrixAt(i, dummy.matrix);
    }

    instancedGravel.instanceMatrix.needsUpdate = true;
    instancedGravel.receiveShadow = true;
    this.group.add(instancedGravel);
  }

  /**
   * 4. Moss-Covered Rocks partially submerged in river
   * Situated right at the waterline (Y: -0.4 to +0.3) with green velvety moss and foam
   */
  private createMossySubmergedRocks() {
    const slateTex = textureFactory.getSlateRockTexture();
    const mossMat = new THREE.MeshStandardMaterial({
      map: slateTex,
      color: new THREE.Color('#5E7348'), // Verdant moss-shaded stone
      roughness: 0.95,
      metalness: 0.02,
    });

    const submergedSpots: [number, number, number][] = [
      // Near dock casting pier
      [-6, -4, 1.2],
      [-5, -1, 1.5],
      [11, -2, 1.4],
      // Along north shoreline
      [5, -3, 1.3],
      [28, -4, 1.6],
      [45, -5, 2.0],
      [78, -3, 2.2],
      // Along south shoreline
      [-10, 3, 1.5],
      [8, 4, 1.8],
      [32, 5, 2.1],
      [65, 4, 2.4],
      [95, 6, 2.5],
    ];

    submergedSpots.forEach(([x, z, scale]) => {
      const geom = new THREE.DodecahedronGeometry(scale, 1);
      const pos = geom.attributes.position;
      for (let i = 0; i < pos.count; i++) {
        const v = new THREE.Vector3(pos.getX(i), pos.getY(i), pos.getZ(i));
        v.multiplyScalar(1.0 + Math.sin(v.y * 3.0) * 0.2);
        pos.setXYZ(i, v.x, v.y, v.z);
      }
      geom.computeVertexNormals();

      const mesh = new THREE.Mesh(geom, mossMat);
      // Situated half in water (water level is 0.0)
      mesh.position.set(x, 0.05, z);
      mesh.rotation.set(Math.random() * Math.PI, Math.random() * Math.PI, 0);
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      this.group.add(mesh);

      // Record foam position for water manager
      this.submergedRockFoamPositions.push(new THREE.Vector3(x, 0.02, z));
    });
  }
}
