/**
 * Grand Chinese Heritage Expansion — Dream World
 * Adds rich Chinese cultural landmarks, architecture, and majestic karst mountain scenery:
 *
 *  1. Mount Tianyun Karst Peaks & Mystic Mountain Sanctuary (Huangshan/Guilin style pinnacles)
 *  2. Cloud Hermitage Daoist Sanctuary (天云仙观 / Tianyun Guan) with Bronze Ding Cauldron, Bell Pavilion & Wishing Ginkgo Tree
 *  3. Great Wall Beacon Tower & Fortified Mountain Ridge (万里长城烽燧与山隘) with signal fire brazier & dragon flags
 *  4. Cliffside Wooden Plank Walkway (悬空栈道 / Zhandao) cantilevered along the sheer mountain rock face
 *  5. Dragon Gate Waterfall & Jade Spring Pavilion (鲤鱼跃龙门 & 碧泉亭) with stone dragon gargoyle
 *  6. Jiangnan Water-Town Quarter (江南水乡民居群) with whitewashed "Horse-Head" fire walls (马头墙) & Moon Bridge
 *  7. Master Siheyuan Quadrangle Mansion (四合院名门大宅) with Spirit Screen Wall (影壁), Verandas, & Courtyard Bonsai
 *  8. Hanlin Scholars' Academy (翰林书院) with Calligraphy Hall, Bamboo Garden & Imperial Exam tables
 *  9. Renxin Traditional Chinese Medicine Apothecary (仁心堂中医药阁) with 100-drawer cabinet & herb trays
 *  10. Temple of Guan Yu / Martial Saint (关帝古庙) with Guardian Lions (Fo Dogs), Guandao weapons rack & bronze incense burner
 *  11. Ancient Stele Forest & Poetry Pavilion (碑林与诗仙亭) with turtle-borne Bixi steles
 *
 * Fully integrated collision, PBR materials, and procedural textures.
 */

import * as THREE from 'three';
import { textureFactory } from './textures';
import { CityCollider } from './ancientCity';

export class ChineseHeritageExpansionManager {
  public group: THREE.Group = new THREE.Group();
  public colliders: CityCollider[] = [];

  // Animated elements
  private animatedRibbons: THREE.Mesh[] = [];
  private animatedFlags: THREE.Mesh[] = [];
  private animatedIncense: THREE.Points | null = null;
  private waterfallPlanes: THREE.Mesh[] = [];
  private floatingLotusLanterns: THREE.Group[] = [];

  constructor() {
    this.buildKarstMountainPeaksAndZhandao();
    this.buildTianyunDaoistSanctuary();
    this.buildGreatWallBeaconTower();
    this.buildDragonGateWaterfall();
    this.buildJiangnanWaterTown();
    this.buildSiheyuanCourtyardMansion();
    this.buildHanlinScholarsAcademy();
    this.buildRenxinMedicineApothecary();
    this.buildGuanYuMartialTemple();
    this.buildSteleForestAndPoetryPavilion();
    this.buildGrandMoonArchBridge();
    this.buildRiversideTeaPavilion();
    this.buildTianyunSevenStoryPagoda();
    this.buildFloatingLotusLanterns();
    this.buildIncenseSmokeParticles();
  }

  /**
   * 1. MOUNT TIANYUN KARST MOUNTAIN PEAKS & CLIFFSIDE WOODEN PLANK WALKWAY (ZHANDAO)
   * High limestone pillars, hanging pines, and walkable cliffside wooden gallery.
   */
  private buildKarstMountainPeaksAndZhandao() {
    const mountainGroup = new THREE.Group();

    const slateTex = textureFactory.getSlateRockTexture();
    slateTex.repeat.set(3, 8);
    const karstRockMat = new THREE.MeshStandardMaterial({
      map: slateTex,
      color: 0x555856,
      roughness: 0.92,
      metalness: 0.05,
      flatShading: true,
    });

    const woodTex = textureFactory.getAncientBridgeWoodTexture();
    woodTex.repeat.set(2, 2);
    const woodMat = new THREE.MeshStandardMaterial({
      map: woodTex,
      color: 0x5C4430,
      roughness: 0.8,
    });

    const redSilkMat = new THREE.MeshStandardMaterial({
      color: 0xDC2626,
      emissive: 0x881111,
      emissiveIntensity: 0.35,
      roughness: 0.6,
    });

    // A. Towering Karst Limestone Spires (Guilin & Huangshan style)
    const peakConfigs = [
      { x: 445, z: 430, baseR: 26, topR: 14, h: 32, y: 12 },
      { x: 485, z: 350, baseR: 24, topR: 11, h: 36, y: 15 },
      { x: 395, z: 505, baseR: 28, topR: 15, h: 30, y: 10 },
      { x: 480, z: 225, baseR: 22, topR: 10, h: 28, y: 4 },
      { x: 345, z: 470, baseR: 18, topR: 8, h: 22, y: 8 },
    ];

    peakConfigs.forEach((pk) => {
      const spireGeom = new THREE.CylinderGeometry(pk.topR, pk.baseR, pk.h, 9);
      const spire = new THREE.Mesh(spireGeom, karstRockMat);
      spire.position.set(pk.x, pk.y + pk.h * 0.5, pk.z);
      spire.castShadow = true;
      spire.receiveShadow = true;
      mountainGroup.add(spire);

      // Add clinging Huangshan mountain pines along rock ledges
      for (let p = 0; p < 3; p++) {
        const ang = (p / 3) * Math.PI * 2 + Math.PI / 4;
        const pineX = pk.x + Math.cos(ang) * (pk.topR + 1.2);
        const pineZ = pk.z + Math.sin(ang) * (pk.topR + 1.2);
        const pineY = pk.y + pk.h * (0.6 + p * 0.12);
        const pine = this.createMountainPine();
        pine.position.set(pineX, pineY, pineZ);
        pine.rotation.y = ang;
        pine.rotation.z = 0.25; // Lean out over the precipice
        mountainGroup.add(pine);
      }
    });

    // B. Cliffside Cantilevered Wooden Plank Walkway (Zhandao / 悬空栈道)
    // Runs along the western mountain face from (X: 365, Z: 385) to (X: 375, Z: 435) at Y = 14.5
    const zhandaoGroup = new THREE.Group();
    const plankMat = woodMat;
    const waypoints: [number, number][] = [
      [362, 385],
      [364, 395],
      [366, 405],
      [368, 415],
      [372, 425],
      [376, 435],
    ];

    for (let i = 0; i < waypoints.length - 1; i++) {
      const p1 = waypoints[i];
      const p2 = waypoints[i + 1];
      const dx = p2[0] - p1[0];
      const dz = p2[1] - p1[1];
      const len = Math.hypot(dx, dz);
      const ang = Math.atan2(dx, dz);
      const midX = (p1[0] + p2[0]) * 0.5;
      const midZ = (p1[1] + p2[1]) * 0.5;

      const seg = new THREE.Group();
      seg.position.set(midX, 14.5, midZ);
      seg.rotation.y = ang;

      // Wooden Deck Platform (2.8m wide)
      const deck = new THREE.Mesh(new THREE.BoxGeometry(2.8, 0.25, len + 0.2), plankMat);
      deck.castShadow = true;
      deck.receiveShadow = true;
      seg.add(deck);

      // Cantilevered Heavy Timber Beams anchored into the mountain rock
      for (let b = -len * 0.4; b <= len * 0.4; b += 2.4) {
        const beam = new THREE.Mesh(new THREE.BoxGeometry(4.5, 0.3, 0.3), plankMat);
        beam.position.set(0.8, -0.25, b);
        seg.add(beam);

        // Diagonal wooden strut bracing back into cliff face
        const strut = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.12, 2.5), plankMat);
        strut.position.set(0.6, -1.2, b);
        strut.rotation.z = -0.55;
        seg.add(strut);
      }

      // Outer safety railing with red hanging lanterns
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.15, 0.95, len + 0.2), plankMat);
      rail.position.set(-1.3, 0.55, 0);
      seg.add(rail);

      for (let r = -len * 0.4; r <= len * 0.4; r += 2.5) {
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.2, 1.1, 0.2), plankMat);
        post.position.set(-1.3, 0.55, r);
        seg.add(post);

        // Hanging red silk mountain lantern
        const lantern = new THREE.Mesh(new THREE.SphereGeometry(0.22, 8, 8), redSilkMat);
        lantern.scale.set(1, 1.3, 1);
        lantern.position.set(-1.3, 0.2, r);
        seg.add(lantern);
      }

      zhandaoGroup.add(seg);

      // Add walkable collider for each walkway segment
      this.colliders.push({
        minX: Math.min(p1[0], p2[0]) - 1.8,
        maxX: Math.max(p1[0], p2[0]) + 1.8,
        minZ: Math.min(p1[1], p2[1]) - 0.5,
        maxZ: Math.max(p1[1], p2[1]) + 0.5,
        height: 14.65,
        surface: 'wood',
      });
    }

    mountainGroup.add(zhandaoGroup);

    // C. Stone Mountain Stairway (ascending from village edge at Z: 345 up to Tianyun Sanctuary)
    const stairCount = 28;
    for (let s = 0; s < stairCount; s++) {
      const t = s / stairCount;
      const sx = THREE.MathUtils.lerp(308, 362, t);
      const sz = THREE.MathUtils.lerp(345, 385, t);
      const sy = THREE.MathUtils.lerp(4.4, 14.5, t);

      const step = new THREE.Mesh(
        new THREE.BoxGeometry(3.6, 0.35, 1.4),
        new THREE.MeshStandardMaterial({ map: slateTex, roughness: 0.85 })
      );
      step.position.set(sx, sy, sz);
      step.rotation.y = 0.45;
      step.castShadow = true;
      step.receiveShadow = true;
      mountainGroup.add(step);
    }

    this.group.add(mountainGroup);
  }

  /**
   * 2. CLOUD HERMITAGE DAOIST SANCTUARY (天云仙观 - Tianyun Guan)
   * High mountain plateau at X: 395, Z: 415, Y = 14.5.
   * Featuring Main Hall of Three Purities, Giant Bronze Ding Cauldron, Bell Pavilion & Wishing Ginkgo.
   */
  private buildTianyunDaoistSanctuary() {
    const templeGroup = new THREE.Group();
    templeGroup.position.set(395, 14.5, 415);

    const stoneTex = textureFactory.getSlateRockTexture();
    const stoneMat = new THREE.MeshStandardMaterial({ map: stoneTex, roughness: 0.85 });
    const redMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getChineseLacqueredRedTexture(),
      roughness: 0.5,
    });
    const darkTileMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getDarkGreyGlazedTileTexture(),
      roughness: 0.65,
    });
    const bronzeMat = new THREE.MeshStandardMaterial({
      color: 0x4B3A26,
      metalness: 0.85,
      roughness: 0.35,
    });

    // 1. Elevated Sanctuary Stone Terrace Plinth (38m x 32m x 1.2m)
    const plinth = new THREE.Mesh(new THREE.BoxGeometry(38, 1.2, 32), stoneMat);
    plinth.position.set(0, 0.6, 0);
    plinth.receiveShadow = true;
    templeGroup.add(plinth);

    // Carved Cloud Stone Balustrades around the terrace
    for (const bz of [-15.5, 15.5]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(38, 0.85, 0.35), stoneMat);
      rail.position.set(0, 1.6, bz);
      templeGroup.add(rail);
    }
    for (const bx of [-18.5, 18.5]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.35, 0.85, 32), stoneMat);
      rail.position.set(bx, 1.6, 0);
      templeGroup.add(rail);
    }

    // 2. Main Hall of Three Purities (Sanqing Dian / 三清殿)
    // 22m x 16m x 9m majestic Daoist sanctuary
    const hallBody = new THREE.Mesh(new THREE.BoxGeometry(20, 5.5, 14), redMat);
    hallBody.position.set(0, 3.95, -6);
    templeGroup.add(hallBody);

    // Vermilion Colonnade Pillars
    for (let x = -9; x <= 9; x += 4.5) {
      for (const z of [-12.5, 0.5]) {
        const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.32, 0.35, 5.5, 12), redMat);
        pillar.position.set(x, 3.95, z);
        templeGroup.add(pillar);
      }
    }

    // Double Flared Dark Glazed Hip Roof
    const lowerRoof = this.createCurvedHipRoof(24, 18, 2.5, darkTileMat);
    lowerRoof.position.set(0, 7.2, -6);
    const upperRoof = this.createCurvedHipRoof(18, 13, 3.0, darkTileMat);
    upperRoof.position.set(0, 10.0, -6);
    templeGroup.add(lowerRoof, upperRoof);

    // Golden Taiji Yin-Yang Emblem on Hall Gable
    const taijiDisc = new THREE.Mesh(
      new THREE.CylinderGeometry(1.2, 1.2, 0.15, 24),
      new THREE.MeshStandardMaterial({ color: 0xD4AF37, metalness: 0.8, roughness: 0.3 })
    );
    taijiDisc.rotation.x = Math.PI / 2;
    taijiDisc.position.set(0, 8.8, 1.2);
    templeGroup.add(taijiDisc);

    // 3. Great Bronze Incense Tripod Ding (大铜鼎 / 香炉)
    const dingGroup = new THREE.Group();
    dingGroup.position.set(0, 1.2, 6);

    const dingBody = new THREE.Mesh(new THREE.CylinderGeometry(1.6, 1.3, 1.4, 16), bronzeMat);
    dingBody.position.set(0, 1.4, 0);
    // 3 Tripod Legs
    for (let l = 0; l < 3; l++) {
      const ang = (l / 3) * Math.PI * 2;
      const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.28, 1.4, 8), bronzeMat);
      leg.position.set(Math.cos(ang) * 1.1, 0.7, Math.sin(ang) * 1.1);
      dingGroup.add(leg);
    }
    // Dragon Loop Handles on West & East rims
    for (const hx of [-1.8, 1.8]) {
      const handle = new THREE.Mesh(new THREE.TorusGeometry(0.45, 0.1, 8, 16), bronzeMat);
      handle.position.set(hx, 2.1, 0);
      handle.rotation.y = Math.PI / 2;
      dingGroup.add(handle);
    }
    // Burning incense ash surface with glowing embers
    const ash = new THREE.Mesh(
      new THREE.CylinderGeometry(1.5, 1.5, 0.1, 16),
      new THREE.MeshStandardMaterial({ color: 0x8C4A2F, emissive: 0xD9531E, emissiveIntensity: 0.6 })
    );
    ash.position.set(0, 2.05, 0);
    dingGroup.add(dingBody, ash);
    templeGroup.add(dingGroup);

    // 4. Temple Bell Pavilion (钟楼) at X: -12, Z: 6
    const bellPavilion = new THREE.Group();
    bellPavilion.position.set(-12, 1.2, 6);
    // 4 Heavy timber posts
    for (const px of [-2.2, 2.2]) {
      for (const pz of [-2.2, 2.2]) {
        const post = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.22, 4.8), redMat);
        post.position.set(px, 2.4, pz);
        bellPavilion.add(post);
      }
    }
    // Bell Roof
    const bRoof = this.createCurvedHipRoof(6.2, 6.2, 1.8, darkTileMat);
    bRoof.position.set(0, 5.4, 0);
    bellPavilion.add(bRoof);

    // Hanging Great Bronze Bell
    const bronzeBell = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 1.2, 1.8, 16), bronzeMat);
    bronzeBell.position.set(0, 3.2, 0);
    bellPavilion.add(bronzeBell);
    templeGroup.add(bellPavilion);

    // 5. Sacred Wishing Ginkgo Tree (Golden Leaves with Red Blessing Silk Ribbons)
    const wishingTree = this.createWishingGinkgoTree();
    wishingTree.position.set(12, 1.2, 6);
    templeGroup.add(wishingTree);

    this.group.add(templeGroup);

    // Sanctuary Collision (Platform surface & main hall walls)
    this.colliders.push({
      minX: 395 - 19,
      maxX: 395 + 19,
      minZ: 415 - 16,
      maxZ: 415 + 16,
      height: 15.7,
      surface: 'stone',
    });
    this.colliders.push({
      minX: 395 - 10,
      maxX: 395 + 10,
      minZ: 415 - 13,
      maxZ: 415 + 1,
      height: 24.0,
      surface: 'wood',
      isSolidWall: true,
    });
  }

  /**
   * 3. GREAT WALL BEACON TOWER & FORTIFIED MOUNTAIN RIDGE (万里长城烽燧与山隘)
   * High peak fortress at X: 435, Z: 315, Y = 18.5.
   * Massive chiseled stone block watchtower, battlements, signal fire brazier, and dragon flags.
   */
  private buildGreatWallBeaconTower() {
    const fortGroup = new THREE.Group();
    fortGroup.position.set(435, 18.5, 315);

    const stoneMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getGreatWallStoneTexture(),
      roughness: 0.88,
    });
    const ironMat = new THREE.MeshStandardMaterial({
      color: 0x2A2A2A,
      metalness: 0.9,
      roughness: 0.4,
    });

    // 1. Massive Stone Podium (13m x 13m x 6.5m) with arched tunnel
    const podLeft = new THREE.Mesh(new THREE.BoxGeometry(4.2, 6.5, 13), stoneMat);
    podLeft.position.set(-4.4, 3.25, 0);
    const podRight = new THREE.Mesh(new THREE.BoxGeometry(4.2, 6.5, 13), stoneMat);
    podRight.position.set(4.4, 3.25, 0);
    const podLintel = new THREE.Mesh(new THREE.BoxGeometry(13, 1.5, 13), stoneMat);
    podLintel.position.set(0, 5.75, 0);
    fortGroup.add(podLeft, podRight, podLintel);

    // 2. Upper Observation Deck & Crenellated Battlements (Parapet with Arrow Slits)
    const deck = new THREE.Mesh(new THREE.BoxGeometry(13, 0.4, 13), stoneMat);
    deck.position.set(0, 6.7, 0);
    fortGroup.add(deck);

    // Crenellations (Merlons along the 4 edges)
    for (const bz of [-6.3, 6.3]) {
      for (let mx = -5; mx <= 5; mx += 2.5) {
        const merlon = new THREE.Mesh(new THREE.BoxGeometry(1.6, 1.2, 0.5), stoneMat);
        merlon.position.set(mx, 7.4, bz);
        fortGroup.add(merlon);
      }
    }
    for (const bx of [-6.3, 6.3]) {
      for (let mz = -5; mz <= 5; mz += 2.5) {
        const merlon = new THREE.Mesh(new THREE.BoxGeometry(0.5, 1.2, 1.6), stoneMat);
        merlon.position.set(bx, 7.4, mz);
        fortGroup.add(merlon);
      }
    }

    // 3. Signal Fire Brazier (烽火铁镬) in center of the deck
    const brazier = new THREE.Mesh(new THREE.CylinderGeometry(1.4, 0.9, 1.0, 12), ironMat);
    brazier.position.set(0, 7.5, 0);
    const embers = new THREE.Mesh(
      new THREE.CylinderGeometry(1.3, 1.3, 0.2, 12),
      new THREE.MeshStandardMaterial({ color: 0xFF4500, emissive: 0xFF2200, emissiveIntensity: 0.9 })
    );
    embers.position.set(0, 7.9, 0);
    fortGroup.add(brazier, embers);

    // 4. Imperial Embroidered Dragon Flags at the 4 corners
    for (const cx of [-6.0, 6.0]) {
      for (const cz of [-6.0, 6.0]) {
        const flagMast = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.1, 4.5), ironMat);
        flagMast.position.set(cx, 8.8, cz);
        fortGroup.add(flagMast);

        const flag = new THREE.Mesh(
          new THREE.PlaneGeometry(1.8, 1.2),
          new THREE.MeshStandardMaterial({
            color: cx > 0 ? 0xD4AF37 : 0xDC2626,
            roughness: 0.8,
            side: THREE.DoubleSide,
          })
        );
        flag.position.set(cx + 0.9, 9.8, cz);
        fortGroup.add(flag);
        this.animatedFlags.push(flag);
      }
    }

    // 5. Connecting Great Wall Ramparts along the mountain crest
    // Section A towards North Peak (Z: +10 to +30)
    const rampartA = new THREE.Mesh(new THREE.BoxGeometry(4.0, 4.5, 24), stoneMat);
    rampartA.position.set(0, 2.25, 18);
    fortGroup.add(rampartA);

    this.group.add(fortGroup);

    // Walkable collision on the Great Wall Observation Deck and tunnel
    this.colliders.push({
      minX: 435 - 6.5,
      maxX: 435 + 6.5,
      minZ: 315 - 6.5,
      maxZ: 315 + 6.5,
      height: 25.2,
      surface: 'stone',
    });
    this.colliders.push({
      minX: 435 - 2.0,
      maxX: 435 + 2.0,
      minZ: 315 + 6,
      maxZ: 315 + 30,
      height: 23.0,
      surface: 'stone',
    });
    // Wall legs collision
    this.colliders.push({
      minX: 435 - 6.5,
      maxX: 435 - 2.3,
      minZ: 315 - 6.5,
      maxZ: 315 + 6.5,
      height: 26.0,
      surface: 'stone',
      isSolidWall: true,
    });
    this.colliders.push({
      minX: 435 + 2.3,
      maxX: 435 + 6.5,
      minZ: 315 - 6.5,
      maxZ: 315 + 6.5,
      height: 26.0,
      surface: 'stone',
      isSolidWall: true,
    });
  }

  /**
   * 4. DRAGON GATE WATERFALL & JADE SPRING PAVILION (鲤鱼跃龙门 & 龙泉)
   * Natural cascading mountain spring at X: 330, Z: 345.
   */
  private buildDragonGateWaterfall() {
    const fallsGroup = new THREE.Group();
    fallsGroup.position.set(330, 4.35, 345);

    const stoneTex = textureFactory.getSlateRockTexture();
    const stoneMat = new THREE.MeshStandardMaterial({ map: stoneTex, roughness: 0.85 });
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x3A7E85,
      roughness: 0.1,
      metalness: 0.3,
      transparent: true,
      opacity: 0.88,
    });

    // 1. Natural Stepped Waterfall Cliff (Rising from Y = 4.35 to 8.5)
    const cliff = new THREE.Mesh(new THREE.BoxGeometry(10, 4.5, 6), stoneMat);
    cliff.position.set(6, 2.25, 0);
    fallsGroup.add(cliff);

    // Carved Dragon Head Gargoyle Waterspout (龙首喷泉)
    const dragonHead = new THREE.Mesh(
      new THREE.BoxGeometry(1.6, 1.2, 2.2),
      new THREE.MeshStandardMaterial({ color: 0x5C6360, roughness: 0.7 })
    );
    dragonHead.position.set(1.5, 4.2, 0);
    fallsGroup.add(dragonHead);

    // Cascading Water Flow Plane
    const waterfallGeom = new THREE.PlaneGeometry(3.5, 5.0);
    const waterfallMesh = new THREE.Mesh(waterfallGeom, waterMat);
    waterfallMesh.position.set(0.6, 2.4, 0);
    waterfallMesh.rotation.y = Math.PI / 2;
    waterfallMesh.rotation.z = -0.25;
    fallsGroup.add(waterfallMesh);
    this.waterfallPlanes.push(waterfallMesh);

    // 2. Lower Jade Carp Pool (14m x 12m) with stone curbs
    const poolWater = new THREE.Mesh(new THREE.PlaneGeometry(12, 10), waterMat);
    poolWater.rotation.x = -Math.PI / 2;
    poolWater.position.set(-6, 0.3, 0);
    fallsGroup.add(poolWater);

    // Stepping Stones across the pool
    for (let s = -4; s <= 4; s += 2) {
      const stepStone = new THREE.Mesh(new THREE.CylinderGeometry(0.6, 0.7, 0.45, 8), stoneMat);
      stepStone.position.set(-6 + s * 0.4, 0.25, s * 0.9);
      fallsGroup.add(stepStone);
    }

    // 3. Hexagonal Jade Spring Pavilion (碧泉亭) beside the pool
    const pavilion = this.createHexagonalPavilion();
    pavilion.position.set(-10, 0, -8);
    fallsGroup.add(pavilion);

    this.group.add(fallsGroup);

    // Collider for the pavilion terrace
    this.colliders.push({
      minX: 330 - 14,
      maxX: 330 - 6,
      minZ: 345 - 12,
      maxZ: 345 - 4,
      height: 4.8,
      surface: 'stone',
    });
  }

  /**
   * 5. JIANGNAN WATER-TOWN CANAL QUARTER (江南水乡民居群)
   * Authentic vernacular homes with whitewashed Horse-Head stepped fire walls (马头墙),
   * black glazed tile eaves, canal balustrades, and stone Moon Bridge.
   */
  private buildJiangnanWaterTown() {
    const townGroup = new THREE.Group();
    townGroup.position.set(80, 3.9, 360);

    const plasterMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getWhitePlasterWallTexture(),
      roughness: 0.9,
    });
    const darkTileMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getDarkGreyGlazedTileTexture(),
      roughness: 0.7,
    });
    const woodMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getAgedWoodTexture(),
      roughness: 0.85,
    });
    const stoneMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getSlateRockTexture(),
      roughness: 0.85,
    });

    // Canal water continuation (X: 18, Z: -40 to +60)
    const canalWater = new THREE.Mesh(
      new THREE.PlaneGeometry(12, 100),
      new THREE.MeshStandardMaterial({
        color: 0x366568,
        roughness: 0.2,
        transparent: true,
        opacity: 0.88,
      })
    );
    canalWater.rotation.x = -Math.PI / 2;
    canalWater.position.set(18, -0.9, 10);
    townGroup.add(canalWater);

    // High Arched Stone Moon Bridge crossing the water-town canal (Z: 10)
    const moonBridge = this.createStoneMoonBridge(stoneMat);
    moonBridge.position.set(18, 0, 10);
    townGroup.add(moonBridge);
    this.colliders.push({
      minX: 80 + 18 - 6.5,
      maxX: 80 + 18 + 6.5,
      minZ: 360 + 10 - 2.5,
      maxZ: 360 + 10 + 2.5,
      height: 6.2,
      surface: 'stone',
    });

    // 4 Authentic Water-Town Mansions with Stepped Horse-Head Walls (马头墙)
    const houses = [
      { x: -8, z: -16, w: 10, d: 12, h: 5.8 },
      { x: -8, z: 16, w: 11, d: 14, h: 6.2 },
      { x: -8, z: 46, w: 10, d: 12, h: 5.6 },
      { x: 42, z: 8, w: 12, d: 14, h: 6.0 },
    ];

    houses.forEach((h) => {
      const house = new THREE.Group();
      house.position.set(h.x, 0, h.z);

      // Main whitewashed building body
      const body = new THREE.Mesh(new THREE.BoxGeometry(h.w, h.h, h.d), plasterMat);
      body.position.set(0, h.h * 0.5, 0);
      body.castShadow = true;
      body.receiveShadow = true;
      house.add(body);

      // Black tile pitched gable roof
      const roof = this.createCurvedHipRoof(h.w + 1.6, h.d + 1.6, 1.8, darkTileMat);
      roof.position.set(0, h.h + 0.8, 0);
      house.add(roof);

      // Distinctive Stepped "Horse-Head" Fire Walls (马头墙) on North & South gable ends
      for (const gz of [-h.d * 0.5 - 0.1, h.d * 0.5 + 0.1]) {
        for (let step = 0; step < 3; step++) {
          const stepW = h.w * (1 - step * 0.28);
          const stepY = h.h + step * 0.65;
          const wallTop = new THREE.Mesh(new THREE.BoxGeometry(stepW, 0.45, 0.4), plasterMat);
          wallTop.position.set(0, stepY, gz);
          // Dark tile cap on the wall step
          const tileCap = new THREE.Mesh(new THREE.BoxGeometry(stepW + 0.3, 0.15, 0.5), darkTileMat);
          tileCap.position.set(0, stepY + 0.28, gz);
          house.add(wallTop, tileCap);
        }
      }

      // Wooden Lattice Windows & Riverside Veranda Balcony facing the canal
      const veranda = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.25, h.d - 2), woodMat);
      veranda.position.set(h.w * 0.5 + 1.2, 1.8, 0);
      const verandaRail = new THREE.Mesh(
        new THREE.BoxGeometry(0.2, 0.8, h.d - 2),
        new THREE.MeshStandardMaterial({ map: textureFactory.getCarvedLatticeTexture(), roughness: 0.7 })
      );
      verandaRail.position.set(h.w * 0.5 + 2.3, 2.2, 0);
      house.add(veranda, verandaRail);

      townGroup.add(house);

      // House solid colliders
      this.colliders.push({
        minX: 80 + h.x - h.w * 0.5,
        maxX: 80 + h.x + h.w * 0.5,
        minZ: 360 + h.z - h.d * 0.5,
        maxZ: 360 + h.z + h.d * 0.5,
        height: h.h + 2.0,
        surface: 'stone',
        isSolidWall: true,
      });
    });

    this.group.add(townGroup);
  }

  /**
   * 6. MASTER SIHEYUAN QUADRANGLE MANSION (四合院名门望族大宅)
   * Ceremonial Guangliang Gate, Spirit Screen Wall (Yingbi / 影壁),
   * North Master Hall, East/West Wing Chambers, covered verandas, central bonsai garden.
   */
  private buildSiheyuanCourtyardMansion() {
    const siheyuanGroup = new THREE.Group();
    siheyuanGroup.position.set(185, 4.35, 365);

    const redMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getChineseLacqueredRedTexture(),
      roughness: 0.5,
    });
    const darkTileMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getDarkGreyGlazedTileTexture(),
      roughness: 0.7,
    });
    const stoneMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getSlateRockTexture(),
      roughness: 0.85,
    });
    const woodMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getAncientBridgeWoodTexture(),
      roughness: 0.8,
    });

    // Outer perimeter courtyard enclosure wall (36m x 32m)
    const wallH = 3.6;
    const wallMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getWhitePlasterWallTexture(),
      roughness: 0.9,
    });

    // Paved courtyard foundation
    const courtFloor = new THREE.Mesh(new THREE.PlaneGeometry(36, 32), stoneMat);
    courtFloor.rotation.x = -Math.PI / 2;
    courtFloor.position.set(0, 0.05, 0);
    courtFloor.receiveShadow = true;
    siheyuanGroup.add(courtFloor);

    // 1. South Ceremonial Gate (Guangliang Gate) with Door-Drum Stones (Men Dun)
    const gateGroup = new THREE.Group();
    gateGroup.position.set(0, 0, 15);
    const gateBody = new THREE.Mesh(new THREE.BoxGeometry(8, 4.2, 4), redMat);
    gateBody.position.set(0, 2.1, 0);
    const gateRoof = this.createCurvedHipRoof(10, 5.5, 1.8, darkTileMat);
    gateRoof.position.set(0, 4.8, 0);
    // Stone Door-Drum Pedestals (抱鼓石)
    for (const mx of [-2.4, 2.4]) {
      const drum = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.45, 0.7, 12), stoneMat);
      drum.position.set(mx, 0.35, 2.2);
      gateGroup.add(drum);
    }
    gateGroup.add(gateBody, gateRoof);
    siheyuanGroup.add(gateGroup);

    // 2. Spirit Screen Wall (Yingbi / 影壁) deflecting bad fortune directly behind the gate
    const yingbiGroup = new THREE.Group();
    yingbiGroup.position.set(0, 0, 9);
    const yingbiBase = new THREE.Mesh(new THREE.BoxGeometry(7.5, 0.6, 1.2), stoneMat);
    yingbiBase.position.set(0, 0.3, 0);
    const yingbiBody = new THREE.Mesh(
      new THREE.BoxGeometry(7.0, 3.2, 0.8),
      new THREE.MeshStandardMaterial({
        map: textureFactory.getSpiritWallReliefTexture(),
        roughness: 0.7,
      })
    );
    yingbiBody.position.set(0, 2.2, 0);
    const yingbiRoof = this.createCurvedHipRoof(8.2, 1.8, 0.9, darkTileMat);
    yingbiRoof.position.set(0, 4.1, 0);
    yingbiGroup.add(yingbiBase, yingbiBody, yingbiRoof);
    siheyuanGroup.add(yingbiGroup);

    // 3. North Principal Master Hall (Zhengfang / 正房)
    const zhengfang = new THREE.Mesh(new THREE.BoxGeometry(18, 5.2, 8), redMat);
    zhengfang.position.set(0, 2.6, -11);
    const zhengfangRoof = this.createCurvedHipRoof(20.5, 10.5, 2.2, darkTileMat);
    zhengfangRoof.position.set(0, 6.0, -11);
    siheyuanGroup.add(zhengfang, zhengfangRoof);

    // 4. East & West Wing Chambers (Xiangfang / 厢房)
    for (const wx of [-14, 14]) {
      const xiangfang = new THREE.Mesh(new THREE.BoxGeometry(6, 4.4, 16), redMat);
      xiangfang.position.set(wx, 2.2, 0);
      const xiangfangRoof = this.createCurvedHipRoof(8.0, 18.5, 1.8, darkTileMat);
      xiangfangRoof.position.set(wx, 5.0, 0);
      siheyuanGroup.add(xiangfang, xiangfangRoof);
    }

    // 5. Central Courtyard Bonsai (Penjing), Goldfish Porcelain Basin & Weiqi (Go) Table
    // Ceramic Goldfish Basin
    const fishBasin = new THREE.Mesh(
      new THREE.CylinderGeometry(1.1, 0.85, 0.9, 16),
      new THREE.MeshStandardMaterial({ color: 0x2A6F97, roughness: 0.3 })
    );
    fishBasin.position.set(-3.5, 0.45, 0);
    siheyuanGroup.add(fishBasin);

    // Penjing Bonsai on carved stone table
    const bonsaiTable = new THREE.Mesh(new THREE.BoxGeometry(2.4, 0.85, 1.2), woodMat);
    bonsaiTable.position.set(3.5, 0.42, 0);
    const bonsaiTree = this.createBonsaiPine();
    bonsaiTree.position.set(3.5, 0.85, 0);
    siheyuanGroup.add(bonsaiTable, bonsaiTree);

    // Stone Weiqi (Go Game) Table with 2 stone garden stools
    const goTable = new THREE.Mesh(new THREE.CylinderGeometry(0.7, 0.6, 0.75, 12), stoneMat);
    goTable.position.set(0, 0.38, -2);
    for (const sx of [-1.1, 1.1]) {
      const stool = new THREE.Mesh(new THREE.CylinderGeometry(0.35, 0.32, 0.45, 10), stoneMat);
      stool.position.set(sx, 0.22, -2);
      siheyuanGroup.add(stool);
    }
    siheyuanGroup.add(goTable);

    this.group.add(siheyuanGroup);

    // Siheyuan Solid Colliders (Zhengfang, Xiangfang wings, Yingbi screen wall)
    this.colliders.push({
      minX: 185 - 9.5,
      maxX: 185 + 9.5,
      minZ: 365 - 15.5,
      maxZ: 365 - 6.5,
      height: 7.5,
      surface: 'wood',
      isSolidWall: true,
    });
    this.colliders.push({
      minX: 185 - 17.5,
      maxX: 185 - 10.5,
      minZ: 365 - 8.5,
      maxZ: 365 + 8.5,
      height: 6.5,
      surface: 'wood',
      isSolidWall: true,
    });
    this.colliders.push({
      minX: 185 + 10.5,
      maxX: 185 + 17.5,
      minZ: 365 - 8.5,
      maxZ: 365 + 8.5,
      height: 6.5,
      surface: 'wood',
      isSolidWall: true,
    });
    // Spirit Wall collider
    this.colliders.push({
      minX: 185 - 3.8,
      maxX: 185 + 3.8,
      minZ: 365 + 8.2,
      maxZ: 365 + 9.8,
      height: 4.5,
      surface: 'stone',
      isSolidWall: true,
    });
  }

  /**
   * 7. HANLIN SCHOLARS' ACADEMY & CALLIGRAPHY HALL (翰林书院)
   * Grand Paifang, Lecture Hall, Calligraphy Scrolls, Bamboo Rock Garden.
   */
  private buildHanlinScholarsAcademy() {
    const academyGroup = new THREE.Group();
    academyGroup.position.set(245, 4.35, 350);

    const redMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getChineseLacqueredRedTexture(),
      roughness: 0.5,
    });
    const darkTileMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getDarkGreyGlazedTileTexture(),
      roughness: 0.7,
    });
    const woodMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getAncientBridgeWoodTexture(),
      roughness: 0.8,
    });

    // 1. Academy Paifang Gate Archway
    const paifang = this.createAcademyPaifang();
    paifang.position.set(0, 0, 14);
    academyGroup.add(paifang);

    // 2. Grand Lecture Hall (Minglun Hall / 明伦堂)
    const hall = new THREE.Mesh(new THREE.BoxGeometry(16, 5.4, 12), redMat);
    hall.position.set(0, 2.7, -4);
    const hallRoof = this.createCurvedHipRoof(18.5, 14.5, 2.2, darkTileMat);
    hallRoof.position.set(0, 6.2, -4);
    academyGroup.add(hall, hallRoof);

    // Calligraphy Xuan Paper Scrolls hanging in the open portico
    for (let c = -4; c <= 4; c += 4) {
      const scroll = new THREE.Mesh(
        new THREE.PlaneGeometry(1.6, 3.2),
        new THREE.MeshStandardMaterial({
          map: textureFactory.getCalligraphyScrollTexture(),
          roughness: 0.85,
        })
      );
      scroll.position.set(c, 3.0, 2.1);
      academyGroup.add(scroll);
    }

    // Scholar Desks with inkstones and brushes
    for (let d = -4; d <= 4; d += 2.8) {
      const desk = new THREE.Mesh(new THREE.BoxGeometry(1.8, 0.75, 0.9), woodMat);
      desk.position.set(d, 0.38, 5.5);
      academyGroup.add(desk);
    }

    this.group.add(academyGroup);

    this.colliders.push({
      minX: 245 - 8.5,
      maxX: 245 + 8.5,
      minZ: 350 - 10.5,
      maxZ: 350 + 2.5,
      height: 7.8,
      surface: 'wood',
      isSolidWall: true,
    });
  }

  /**
   * 8. RENXIN TRADITIONAL CHINESE MEDICINE APOTHECARY (仁心堂中医药阁)
   * 100-drawer medicine cabinet (Baizi Gui), dried herb bunches, bronze scales, herb drying racks.
   */
  private buildRenxinMedicineApothecary() {
    const apoGroup = new THREE.Group();
    apoGroup.position.set(285, 4.35, 260);

    const woodMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getAncientBridgeWoodTexture(),
      roughness: 0.8,
    });
    const tileMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getChineseRoofTileTexture(),
      roughness: 0.7,
    });

    // Apothecary Hall Building
    const building = new THREE.Mesh(new THREE.BoxGeometry(10, 4.6, 9), woodMat);
    building.position.set(0, 2.3, 0);
    const roof = this.createCurvedHipRoof(12, 11, 1.8, tileMat);
    roof.position.set(0, 5.2, 0);
    apoGroup.add(building, roof);

    // Front Medicine Counter & Herbal Dispensary
    const counter = new THREE.Mesh(new THREE.BoxGeometry(5.5, 0.95, 0.8), woodMat);
    counter.position.set(0, 0.48, 4.8);
    apoGroup.add(counter);

    // Hanging sign: "仁心堂 · 悬壶济世" (Renxin Hall - Medicine to Aid the World)
    const sign = new THREE.Mesh(
      new THREE.BoxGeometry(4.2, 0.8, 0.08),
      new THREE.MeshStandardMaterial({ color: 0x1E1E1E })
    );
    sign.position.set(0, 3.8, 4.6);
    apoGroup.add(sign);

    // Outdoor Circular Bamboo Herb Drying Trays (晾药架) in forecourt
    const trayMat = new THREE.MeshStandardMaterial({ color: 0xC4A46C, roughness: 0.9 });
    for (let t = 0; t < 3; t++) {
      const stand = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.12, 0.9), woodMat);
      stand.position.set(-3.5 + t * 2.2, 0.45, 7.5);
      const tray = new THREE.Mesh(new THREE.CylinderGeometry(0.9, 0.85, 0.12, 16), trayMat);
      tray.position.set(-3.5 + t * 2.2, 0.95, 7.5);
      apoGroup.add(stand, tray);
    }

    this.group.add(apoGroup);

    this.colliders.push({
      minX: 285 - 5.5,
      maxX: 285 + 5.5,
      minZ: 260 - 5.0,
      maxZ: 260 + 5.0,
      height: 6.8,
      surface: 'wood',
      isSolidWall: true,
    });
  }

  /**
   * 9. TEMPLE OF GUAN YU / MARTIAL SAINT (关帝古庙)
   * Guardian Stone Lions (Fo Dogs), vermilion pillars, Guandao weapons rack, ceremonial tripod.
   */
  private buildGuanYuMartialTemple() {
    const templeGroup = new THREE.Group();
    templeGroup.position.set(295, 4.35, 205);

    const redMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getChineseLacqueredRedTexture(),
      roughness: 0.5,
    });
    const yellowTileMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getImperialYellowRoofTileTexture(),
      roughness: 0.5,
    });
    const stoneMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getSlateRockTexture(),
      roughness: 0.85,
    });

    // 1. Temple Hall (14m x 12m)
    const hall = new THREE.Mesh(new THREE.BoxGeometry(14, 5.5, 12), redMat);
    hall.position.set(0, 2.75, 0);
    const roof = this.createCurvedHipRoof(16.5, 14.5, 2.5, yellowTileMat);
    roof.position.set(0, 6.3, 0);
    templeGroup.add(hall, roof);

    // 2. Pair of Carved Guardian Lions (Shi / Fo Dogs / 石狮) flanking the portal
    for (const lx of [-4.2, 4.2]) {
      const lionPlinth = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.8, 1.6), stoneMat);
      lionPlinth.position.set(lx, 0.4, 7.2);
      const lionBody = new THREE.Mesh(
        new THREE.BoxGeometry(0.9, 1.2, 1.2),
        new THREE.MeshStandardMaterial({ color: 0x6E6E6E, roughness: 0.8 })
      );
      lionBody.position.set(lx, 1.3, 7.2);
      templeGroup.add(lionPlinth, lionBody);
    }

    // 3. Guandao & Halberd Ceremonial Weapons Rack (兵器架)
    const rack = new THREE.Group();
    rack.position.set(0, 0, 7.0);
    const rackFrame = new THREE.Mesh(new THREE.BoxGeometry(3.5, 1.8, 0.4), redMat);
    rackFrame.position.set(0, 0.9, 0);
    // Green Dragon Crescent Blade (Guandao)
    const pole = new THREE.Mesh(
      new THREE.CylinderGeometry(0.04, 0.04, 2.8),
      new THREE.MeshStandardMaterial({ color: 0x333333 })
    );
    pole.position.set(0, 1.4, 0.2);
    const blade = new THREE.Mesh(
      new THREE.BoxGeometry(0.2, 0.8, 0.04),
      new THREE.MeshStandardMaterial({ color: 0xC0C0C0, metalness: 0.9, roughness: 0.2 })
    );
    blade.position.set(0, 2.7, 0.2);
    rack.add(rackFrame, pole, blade);
    templeGroup.add(rack);

    this.group.add(templeGroup);

    this.colliders.push({
      minX: 295 - 7.5,
      maxX: 295 + 7.5,
      minZ: 205 - 6.5,
      maxZ: 205 + 6.5,
      height: 8.5,
      surface: 'stone',
      isSolidWall: true,
    });
  }

  /**
   * 10. ANCIENT STELE FOREST & POETRY PAVILION (碑林与诗仙亭)
   * Turtle-borne Bixi steles recording immortal Tang & Song poetry by Li Bai and Du Fu.
   */
  private buildSteleForestAndPoetryPavilion() {
    const forestGroup = new THREE.Group();
    forestGroup.position.set(225, 4.35, 305);

    const stoneMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getSlateRockTexture(),
      roughness: 0.85,
    });

    // 4 Ancient Inscription Bixi Steles (神龟驼碑)
    const stelePositions = [
      { x: -5, z: -3 },
      { x: 5, z: -3 },
      { x: -5, z: 3 },
      { x: 5, z: 3 },
    ];

    stelePositions.forEach((pos) => {
      const stele = new THREE.Group();
      stele.position.set(pos.x, 0, pos.z);

      // Dragon-Turtle Bixi Base
      const turtle = new THREE.Mesh(new THREE.BoxGeometry(1.6, 0.6, 2.2), stoneMat);
      turtle.position.set(0, 0.3, 0);
      // Tall Stone Inscription Tablet
      const tablet = new THREE.Mesh(new THREE.BoxGeometry(1.1, 2.8, 0.3), stoneMat);
      tablet.position.set(0, 1.9, 0);
      // Dragon-head crown finial
      const crown = new THREE.Mesh(new THREE.ConeGeometry(0.7, 0.6, 4), stoneMat);
      crown.position.set(0, 3.5, 0);

      stele.add(turtle, tablet, crown);
      forestGroup.add(stele);
    });

    // Central Poetry Gazebo
    const gazebo = this.createHexagonalPavilion();
    gazebo.position.set(0, 0, 0);
    forestGroup.add(gazebo);

    this.group.add(forestGroup);
  }

  /**
   * 11. PROCEDURAL INCENSE SMOKE PARTICLES
   * Rising ethereal incense smoke plumes at the Daoist Ding and Guan Yu Temple.
   */
  private buildIncenseSmokeParticles() {
    const particleCount = 120;
    const geom = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount; i++) {
      // Half around Daoist Ding (395, 17.5, 421), half around Temple (295, 5.8, 212)
      const isTemple = i % 2 === 0;
      const baseX = isTemple ? 395 : 295;
      const baseY = isTemple ? 17.5 : 5.8;
      const baseZ = isTemple ? 421 : 212;

      positions[i * 3] = baseX + (Math.random() - 0.5) * 0.8;
      positions[i * 3 + 1] = baseY + Math.random() * 4.5;
      positions[i * 3 + 2] = baseZ + (Math.random() - 0.5) * 0.8;
    }

    geom.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const mat = new THREE.PointsMaterial({
      color: 0xE0E0E0,
      size: 0.35,
      transparent: true,
      opacity: 0.45,
    });

    this.animatedIncense = new THREE.Points(geom, mat);
    this.group.add(this.animatedIncense);
  }

  // -----------------------------------------------------------------
  // PROCEDURAL 3D ARCHITECTURAL HELPERS
  // -----------------------------------------------------------------

  private createCurvedHipRoof(width: number, depth: number, height: number, material: THREE.Material): THREE.Mesh {
    const geom = new THREE.ConeGeometry(Math.max(width, depth) * 0.68, height, 4);
    geom.rotateY(Math.PI / 4);
    geom.scale(width / Math.max(width, depth), 1.0, depth / Math.max(width, depth));
    const mesh = new THREE.Mesh(geom, material);
    mesh.castShadow = true;
    return mesh;
  }

  private createHexagonalPavilion(): THREE.Group {
    const pav = new THREE.Group();
    const woodMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getAncientBridgeWoodTexture(),
      roughness: 0.75,
    });
    const tileMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getDarkGreyGlazedTileTexture(),
      roughness: 0.7,
    });

    const r = 2.6;
    for (let i = 0; i < 6; i++) {
      const ang = (i / 6) * Math.PI * 2;
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.14, 0.14, 3.6), woodMat);
      col.position.set(Math.cos(ang) * r, 1.8, Math.sin(ang) * r);
      pav.add(col);
    }
    const roof = new THREE.Mesh(new THREE.ConeGeometry(r * 1.5, 1.8, 6), tileMat);
    roof.position.set(0, 4.2, 0);
    pav.add(roof);
    return pav;
  }

  private createStoneMoonBridge(stoneMat: THREE.Material): THREE.Group {
    const bridge = new THREE.Group();
    // Arched Deck
    const archDeck = new THREE.Mesh(new THREE.BoxGeometry(13, 0.6, 5.0), stoneMat);
    archDeck.position.set(0, 1.4, 0);
    bridge.add(archDeck);

    // Carved balustrades
    for (const bz of [-2.3, 2.3]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(13, 0.8, 0.25), stoneMat);
      rail.position.set(0, 2.0, bz);
      bridge.add(rail);
      for (let rx = -5.5; rx <= 5.5; rx += 2.2) {
        const post = new THREE.Mesh(new THREE.BoxGeometry(0.3, 1.1, 0.3), stoneMat);
        post.position.set(rx, 2.1, bz);
        bridge.add(post);
      }
    }
    return bridge;
  }

  private createMountainPine(): THREE.Group {
    const pine = new THREE.Group();
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x4A3728, roughness: 0.9 });
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x2D4F38, roughness: 0.8 });

    // Weathered twisted trunk
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.3, 3.5, 6), woodMat);
    trunk.position.set(0, 1.75, 0);
    pine.add(trunk);

    // Layered umbrella needle boughs
    for (let l = 0; l < 3; l++) {
      const bough = new THREE.Mesh(new THREE.ConeGeometry(2.0 - l * 0.45, 0.8, 7), leafMat);
      bough.position.set(0.4 * l, 2.4 + l * 0.8, 0);
      pine.add(bough);
    }
    return pine;
  }

  private createWishingGinkgoTree(): THREE.Group {
    const tree = new THREE.Group();
    const barkMat = new THREE.MeshStandardMaterial({ color: 0x5C4A3A, roughness: 0.9 });
    const ginkgoGoldMat = new THREE.MeshStandardMaterial({
      color: 0xF4B942,
      roughness: 0.7,
      side: THREE.DoubleSide,
    });
    const redSilkMat = new THREE.MeshStandardMaterial({
      color: 0xDC2626,
      roughness: 0.5,
      side: THREE.DoubleSide,
    });

    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.4, 0.6, 5.0, 8), barkMat);
    trunk.position.set(0, 2.5, 0);
    tree.add(trunk);

    // Golden leaf crown
    for (let c = 0; c < 4; c++) {
      const leafCluster = new THREE.Mesh(new THREE.DodecahedronGeometry(2.2 - c * 0.3, 1), ginkgoGoldMat);
      leafCluster.position.set((Math.random() - 0.5) * 1.5, 4.5 + c * 1.2, (Math.random() - 0.5) * 1.5);
      tree.add(leafCluster);
    }

    // Hanging Red Silk Blessing Ribbons (许愿红丝带)
    for (let r = 0; r < 8; r++) {
      const ribbon = new THREE.Mesh(new THREE.PlaneGeometry(0.12, 1.6), redSilkMat);
      const ang = (r / 8) * Math.PI * 2;
      ribbon.position.set(Math.cos(ang) * 1.8, 3.6, Math.sin(ang) * 1.8);
      tree.add(ribbon);
      this.animatedRibbons.push(ribbon);
    }
    return tree;
  }

  private createBonsaiPine(): THREE.Group {
    const bonsai = new THREE.Group();
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x4A3728 });
    const leafMat = new THREE.MeshStandardMaterial({ color: 0x2A5235 });

    // Ceramic bonsai pot
    const pot = new THREE.Mesh(
      new THREE.CylinderGeometry(0.6, 0.45, 0.3, 8),
      new THREE.MeshStandardMaterial({ color: 0x6E4A35 })
    );
    pot.position.set(0, 0.15, 0);
    bonsai.add(pot);

    // Twisted bonsai trunk
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.1, 0.9, 6), woodMat);
    trunk.position.set(0.1, 0.6, 0);
    trunk.rotation.z = -0.25;
    const crown = new THREE.Mesh(new THREE.SphereGeometry(0.35, 6, 6), leafMat);
    crown.position.set(-0.1, 1.0, 0);
    bonsai.add(trunk, crown);
    return bonsai;
  }

  private createAcademyPaifang(): THREE.Group {
    const arch = new THREE.Group();
    const redMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getChineseLacqueredRedTexture(),
      roughness: 0.5,
    });
    const darkTileMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getDarkGreyGlazedTileTexture(),
      roughness: 0.7,
    });

    for (const cx of [-3.5, 3.5]) {
      const col = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.25, 5.5), redMat);
      col.position.set(cx, 2.75, 0);
      arch.add(col);
    }
    const lintel = new THREE.Mesh(new THREE.BoxGeometry(8.5, 0.8, 0.5), redMat);
    lintel.position.set(0, 4.8, 0);
    const roof = this.createCurvedHipRoof(9.8, 2.4, 1.4, darkTileMat);
    roof.position.set(0, 5.8, 0);
    arch.add(lintel, roof);
    return arch;
  }

  private createRedLantern(): THREE.Group {
    const lantern = new THREE.Group();
    const redMat = new THREE.MeshStandardMaterial({
      color: 0xDC2626,
      emissive: 0x991111,
      emissiveIntensity: 0.6,
      roughness: 0.4,
    });
    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xD4AF37,
      metalness: 0.8,
      roughness: 0.25,
    });
    const body = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.24, 0.55, 12), redMat);
    const topCap = new THREE.Mesh(new THREE.CylinderGeometry(0.18, 0.25, 0.08, 12), goldMat);
    topCap.position.y = 0.3;
    const btmCap = new THREE.Mesh(new THREE.CylinderGeometry(0.25, 0.18, 0.08, 12), goldMat);
    btmCap.position.y = -0.3;
    const tassel = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.08, 0.35, 8), redMat);
    tassel.position.y = -0.48;
    lantern.add(body, topCap, btmCap, tassel);
    return lantern;
  }

  /**
   * 11. GRAND CHINESE MOON ARCH BRIDGE (月拱石桥 - Yue Gong Qiao)
   * High-clearance classical single-arch stone bridge spanning the newly widened river
   * (X: 58, Z: -36 to +36, Peak Deck Height: Y = 6.2m)
   */
  private buildGrandMoonArchBridge() {
    const bridgeGroup = new THREE.Group();
    bridgeGroup.position.set(58, 0, 0);

    const stoneTex = textureFactory.getWhitePlasterWallTexture();
    const stoneMat = new THREE.MeshStandardMaterial({
      color: 0xCAC7BE,
      roughness: 0.8,
      metalness: 0.05,
    });

    const railMat = new THREE.MeshStandardMaterial({
      color: 0xDDD9D0,
      roughness: 0.75,
    });

    const redSilkMat = new THREE.MeshStandardMaterial({
      color: 0xDC2626,
      emissive: 0x991111,
      emissiveIntensity: 0.4,
      roughness: 0.5,
    });

    // Massive Stone Pier abutments on north and south riverbanks
    for (const bz of [-36, 36]) {
      const pier = new THREE.Mesh(new THREE.BoxGeometry(7.2, 5.5, 9.0), stoneMat);
      pier.position.set(0, 1.5, bz);
      pier.castShadow = true;
      pier.receiveShadow = true;
      bridgeGroup.add(pier);
    }

    // High Arch Stone Vault
    // Semi-circular arch clearing boats underneath (Radius: 26m, centered at Y = -18)
    const archSegments = 24;
    const archSpan = 70; // From Z = -35 to Z = +35
    for (let i = 0; i < archSegments; i++) {
      const t = (i + 0.5) / archSegments;
      const z = -35 + t * archSpan;
      // Parabolic arch profile
      const normalizedZ = (z / 35.0);
      const deckY = 6.2 * (1.0 - normalizedZ * normalizedZ * 0.75) + 0.5;

      const stepSlab = new THREE.Mesh(new THREE.BoxGeometry(6.4, 0.45, archSpan / archSegments + 0.2), stoneMat);
      stepSlab.position.set(0, deckY, z);
      stepSlab.castShadow = true;
      stepSlab.receiveShadow = true;
      bridgeGroup.add(stepSlab);

      // Stone Balustrade with Carved Panels & Posts
      for (const side of [-3.0, 3.0]) {
        const balustrade = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.95, archSpan / archSegments + 0.05), railMat);
        balustrade.position.set(side, deckY + 0.5, z);
        bridgeGroup.add(balustrade);

        // Lion Foo Dog post cap every other segment
        if (i % 2 === 0) {
          const post = new THREE.Mesh(new THREE.BoxGeometry(0.32, 1.25, 0.32), railMat);
          post.position.set(side, deckY + 0.65, z);
          const lionHead = new THREE.Mesh(new THREE.SphereGeometry(0.14, 8, 8), stoneMat);
          lionHead.position.set(side, deckY + 1.35, z);
          bridgeGroup.add(post, lionHead);
        }
      }
    }

    // Keystones with carved dragon mouth (Chiwen) on east and west arch faces
    for (const face of [-3.3, 3.3]) {
      const dragonKeystone = new THREE.Mesh(new THREE.BoxGeometry(0.4, 0.8, 1.2), stoneMat);
      dragonKeystone.position.set(face, 6.4, 0);
      bridgeGroup.add(dragonKeystone);
    }

    // Traditional Red Lanterns hanging on the bridge approaches
    for (const bz of [-22, -8, 8, 22]) {
      for (const bx of [-3.1, 3.1]) {
        const t = Math.abs(bz) / 35.0;
        const ly = 6.2 * (1.0 - t * t * 0.75) + 1.8;
        const lantern = this.createRedLantern();
        lantern.position.set(bx, ly, bz);
        bridgeGroup.add(lantern);
      }
    }

    // Walkable collision bounding boxes across the arch
    this.colliders.push(
      { minX: 54.5, maxX: 61.5, minZ: -12, maxZ: 12, height: 6.6, surface: 'stone' },
      { minX: 54.5, maxX: 61.5, minZ: -24, maxZ: -12, height: 5.2, surface: 'stone' },
      { minX: 54.5, maxX: 61.5, minZ: 12, maxZ: 24, height: 5.2, surface: 'stone' },
      { minX: 54.5, maxX: 61.5, minZ: -36, maxZ: -24, height: 2.8, surface: 'stone' },
      { minX: 54.5, maxX: 61.5, minZ: 24, maxZ: 36, height: 2.8, surface: 'stone' }
    );

    this.group.add(bridgeGroup);
  }

  /**
   * 12. RIVERSIDE IMPERIAL TEA PAVILION & WATER VERANDA (临水飞檐水榭)
   * Built on stilts extending over the broad river with double flying eaves and celadon tea set
   * (X: 25, Z: 28, Deck Height: Y = 1.9m)
   */
  private buildRiversideTeaPavilion() {
    const teaGroup = new THREE.Group();
    teaGroup.position.set(25, 0, 28);

    const darkTileMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getDarkGreyGlazedTileTexture(),
      color: 0x33363B,
      roughness: 0.65,
    });

    const woodMat = new THREE.MeshStandardMaterial({
      map: textureFactory.getAncientBridgeWoodTexture(),
      color: 0x5C4430,
      roughness: 0.8,
    });

    const vermilionMat = new THREE.MeshStandardMaterial({
      color: 0x9E2A2B,
      roughness: 0.6,
    });

    const celadonMat = new THREE.MeshStandardMaterial({
      color: 0x8FA89B,
      roughness: 0.25,
      metalness: 0.15,
    });

    // Submerged timber foundation pilings
    for (const px of [-5.0, 0, 5.0]) {
      for (const pz of [-4.5, 0, 4.5]) {
        const stilt = new THREE.Mesh(new THREE.CylinderGeometry(0.24, 0.26, 6.0, 10), woodMat);
        stilt.position.set(px, -1.0, pz);
        teaGroup.add(stilt);
      }
    }

    // Walkable Tea Veranda Floor Deck
    const deck = new THREE.Mesh(new THREE.BoxGeometry(11.5, 0.35, 10.5), woodMat);
    deck.position.set(0, 1.9, 0);
    deck.castShadow = true;
    deck.receiveShadow = true;
    teaGroup.add(deck);

    // Carved wooden perimeter balustrade
    for (const sx of [-5.5, 5.5]) {
      const rail = new THREE.Mesh(new THREE.BoxGeometry(0.18, 0.9, 10.2), woodMat);
      rail.position.set(sx, 2.45, 0);
      teaGroup.add(rail);
    }
    const southRail = new THREE.Mesh(new THREE.BoxGeometry(11.0, 0.9, 0.18), woodMat);
    southRail.position.set(0, 2.45, 5.1);
    teaGroup.add(southRail);

    // Vermilion Pavilion Pillars
    for (const cx of [-4.5, 4.5]) {
      for (const cz of [-3.8, 3.8]) {
        const pillar = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.24, 4.2, 12), vermilionMat);
        pillar.position.set(cx, 4.0, cz);
        pillar.castShadow = true;
        teaGroup.add(pillar);
      }
    }

    // Double-tiered Curved Flying-Eave Roof
    const lowerRoof = this.createCurvedHipRoof(13.2, 12.2, 1.6, darkTileMat);
    lowerRoof.position.set(0, 6.2, 0);
    const upperRoof = this.createCurvedHipRoof(8.5, 7.5, 1.8, darkTileMat);
    upperRoof.position.set(0, 7.8, 0);
    teaGroup.add(lowerRoof, upperRoof);

    // Golden roof gourd finial (Baoding)
    const finial = new THREE.Mesh(
      new THREE.SphereGeometry(0.35, 12, 12),
      new THREE.MeshStandardMaterial({ color: 0xD4AF37, metalness: 0.85, roughness: 0.25 })
    );
    finial.position.set(0, 9.4, 0);
    teaGroup.add(finial);

    // Interior Tea Tables & Celadon Tea Sets
    for (const tx of [-2.4, 2.4]) {
      const table = new THREE.Mesh(new THREE.CylinderGeometry(1.1, 1.1, 0.65, 14), woodMat);
      table.position.set(tx, 2.3, 0);
      teaGroup.add(table);

      // Celadon Teapot
      const pot = new THREE.Mesh(new THREE.SphereGeometry(0.14, 10, 8), celadonMat);
      pot.position.set(tx, 2.72, 0);
      const spout = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.04, 0.12), celadonMat);
      spout.rotation.z = Math.PI / 4;
      spout.position.set(tx + 0.12, 2.76, 0);
      teaGroup.add(pot, spout);

      // 3 Small Teacups
      for (let c = 0; c < 3; c++) {
        const ang = (c / 3) * Math.PI * 2;
        const cup = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.03, 0.06, 8), celadonMat);
        cup.position.set(tx + Math.cos(ang) * 0.38, 2.68, Math.sin(ang) * 0.38);
        teaGroup.add(cup);
      }
    }

    // 4 Red Silk Lanterns at corner eaves
    for (const lx of [-5.8, 5.8]) {
      for (const lz of [-5.2, 5.2]) {
        const lantern = this.createRedLantern();
        lantern.position.set(lx, 5.6, lz);
        teaGroup.add(lantern);
      }
    }

    // Walkway connecting tea pavilion to northern embankment
    const bridgeWay = new THREE.Mesh(new THREE.BoxGeometry(4.2, 0.3, 8.5), woodMat);
    bridgeWay.position.set(0, 1.9, -8.0);
    teaGroup.add(bridgeWay);

    this.colliders.push(
      { minX: 19.0, maxX: 31.0, minZ: 22.5, maxZ: 33.5, height: 1.9, surface: 'wood' },
      { minX: 22.8, maxX: 27.2, minZ: 16.0, maxZ: 22.5, height: 1.9, surface: 'wood' }
    );

    this.group.add(teaGroup);
  }

  /**
   * 13. TOWERING 7-TIER OCTAGONAL CHINESE PAGODA (七层玲珑宝塔 - Tianyun Pagoda)
   * High historic dynastic tower situated at the karst mountain pass with eaves bells
   * (X: 350, Z: 310, Height: 26.5m)
   */
  private buildTianyunSevenStoryPagoda() {
    const pagodaGroup = new THREE.Group();
    pagodaGroup.position.set(350, 4.35, 310);

    const stoneTex = textureFactory.getGreatWallStoneTexture();
    const stoneMat = new THREE.MeshStandardMaterial({
      map: stoneTex,
      color: 0x8A8E89,
      roughness: 0.85,
    });

    const tileTex = textureFactory.getDarkGreyGlazedTileTexture();
    const tileMat = new THREE.MeshStandardMaterial({
      map: tileTex,
      color: 0x2A2E33,
      roughness: 0.6,
    });

    const vermilionMat = new THREE.MeshStandardMaterial({
      color: 0x8E2829,
      roughness: 0.7,
    });

    const goldMat = new THREE.MeshStandardMaterial({
      color: 0xD4AF37,
      metalness: 0.88,
      roughness: 0.2,
    });

    // 1. Two-Tier Octagonal Stepped Stone Plinth
    const base1 = new THREE.Mesh(new THREE.CylinderGeometry(9.5, 10.5, 1.2, 8), stoneMat);
    base1.position.y = 0.6;
    base1.castShadow = true;
    const base2 = new THREE.Mesh(new THREE.CylinderGeometry(8.0, 8.8, 1.0, 8), stoneMat);
    base2.position.y = 1.7;
    base2.castShadow = true;
    pagodaGroup.add(base1, base2);

    // 2. 7 Octagonal Tiers
    let currentY = 2.2;
    const totalTiers = 7;
    for (let t = 0; t < totalTiers; t++) {
      const tierProgress = t / totalTiers;
      const tierRadius = 6.8 * (1.0 - tierProgress * 0.45);
      const tierHeight = 3.2 * (1.0 - tierProgress * 0.15);

      // Octagonal Body
      const body = new THREE.Mesh(new THREE.CylinderGeometry(tierRadius * 0.92, tierRadius, tierHeight, 8), vermilionMat);
      body.position.y = currentY + tierHeight * 0.5;
      body.castShadow = true;
      pagodaGroup.add(body);

      // Balcony Balustrade around tier
      const balcony = new THREE.Mesh(new THREE.CylinderGeometry(tierRadius + 0.5, tierRadius + 0.5, 0.45, 8), stoneMat);
      balcony.position.y = currentY + 0.25;
      pagodaGroup.add(balcony);

      // Upturned Eaved Roof
      const roofRadius = tierRadius + 1.8;
      const roofCone = new THREE.Mesh(new THREE.ConeGeometry(roofRadius, 1.2, 8), tileMat);
      roofCone.position.y = currentY + tierHeight + 0.6;
      roofCone.castShadow = true;
      pagodaGroup.add(roofCone);

      // Corner wind bells (Fengling) on all 8 eave corners
      for (let c = 0; c < 8; c++) {
        const ang = (c / 8) * Math.PI * 2;
        const bx = Math.cos(ang) * (roofRadius - 0.1);
        const bz = Math.sin(ang) * (roofRadius - 0.1);
        const bell = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.08, 0.16, 6), goldMat);
        bell.position.set(bx, currentY + tierHeight + 0.05, bz);
        pagodaGroup.add(bell);
      }

      currentY += tierHeight + 0.8;
    }

    // 3. Golden Pagoda Spire (Tasha / 宝刹)
    const spireBase = new THREE.Mesh(new THREE.SphereGeometry(1.2, 12, 12), goldMat);
    spireBase.position.y = currentY + 0.8;
    const spireNeedle = new THREE.Mesh(new THREE.ConeGeometry(0.35, 4.5, 12), goldMat);
    spireNeedle.position.y = currentY + 3.4;
    pagodaGroup.add(spireBase, spireNeedle);

    // 9 Sacred Rings on the spire
    for (let r = 0; r < 5; r++) {
      const ring = new THREE.Mesh(new THREE.TorusGeometry(0.6 - r * 0.07, 0.05, 8, 16), goldMat);
      ring.rotation.x = Math.PI / 2;
      ring.position.y = currentY + 1.8 + r * 0.45;
      pagodaGroup.add(ring);
    }

    this.colliders.push({
      minX: 341.0,
      maxX: 359.0,
      minZ: 301.0,
      maxZ: 319.0,
      height: 6.55,
      surface: 'stone',
      isSolidWall: true,
    });

    this.group.add(pagodaGroup);
  }

  /**
   * 14. FLOATING GLOWING LOTUS WATER LANTERNS (水上盛放莲花灯)
   * 16 floating sacred lotus lanterns drifting on the widened river with warm glowing candles
   */
  private buildFloatingLotusLanterns() {
    const lotusGroup = new THREE.Group();

    const petalMat = new THREE.MeshStandardMaterial({
      color: 0xF472B6, // Soft lotus pink
      roughness: 0.4,
      emissive: 0x9D174D,
      emissiveIntensity: 0.35,
    });

    const leafMat = new THREE.MeshStandardMaterial({
      color: 0x15803D, // Lilypad green
      roughness: 0.7,
    });

    const candleMat = new THREE.MeshStandardMaterial({
      color: 0xFDE047,
      emissive: 0xF59E0B,
      emissiveIntensity: 0.9,
      roughness: 0.2,
    });

    // 16 lotus positions scattered along the wide river (X: -40 to 180, Z: -24 to 24)
    const lotusPositions: [number, number][] = [
      [-30, -12], [-15, 8], [5, -16], [22, 12], [40, -8],
      [58, 14], [75, -18], [95, 6], [115, -12], [135, 15],
      [150, -5], [170, 10], [-5, 2], [50, -2], [90, -4], [130, 2]
    ];

    lotusPositions.forEach(([lx, lz], idx) => {
      const lotus = new THREE.Group();
      lotus.position.set(lx, 0.04, lz);

      // Floating lilypad leaf
      const lilypad = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.85, 0.02, 16), leafMat);
      lotus.add(lilypad);

      // 8 Angled pink petals
      for (let p = 0; p < 8; p++) {
        const ang = (p / 8) * Math.PI * 2;
        const petal = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.48, 5), petalMat);
        petal.position.set(Math.cos(ang) * 0.36, 0.22, Math.sin(ang) * 0.36);
        petal.rotation.x = Math.sin(ang) * 0.45;
        petal.rotation.z = -Math.cos(ang) * 0.45;
        lotus.add(petal);
      }

      // Glowing golden candle core
      const candle = new THREE.Mesh(new THREE.CylinderGeometry(0.08, 0.08, 0.25, 8), candleMat);
      candle.position.y = 0.16;
      lotus.add(candle);

      this.floatingLotusLanterns.push(lotus);
      lotusGroup.add(lotus);
    });

    this.group.add(lotusGroup);
  }

  /**
   * Animation update for flags, wishing ribbons, incense smoke, waterfall, and floating lotus lanterns
   */
  public update(delta: number, elapsed: number) {
    // 1. Fluttering mountain dragon flags
    this.animatedFlags.forEach((flag, i) => {
      flag.rotation.y = Math.sin(elapsed * 4.0 + i) * 0.25;
      flag.rotation.z = Math.cos(elapsed * 3.5 + i) * 0.1;
    });

    // 2. Wishing Ginkgo red ribbons sway in the breeze
    this.animatedRibbons.forEach((rib, i) => {
      rib.rotation.z = Math.sin(elapsed * 2.0 + i) * 0.18;
    });

    // 3. Ethereal incense smoke rising
    if (this.animatedIncense) {
      const pos = this.animatedIncense.geometry.attributes.position;
      for (let i = 0; i < pos.count; i++) {
        let y = pos.getY(i) + delta * 0.8;
        const isTemple = i % 2 === 0;
        const topLimit = isTemple ? 22.0 : 10.0;
        const resetY = isTemple ? 17.5 : 5.8;
        if (y > topLimit) y = resetY;
        pos.setY(i, y);
      }
      pos.needsUpdate = true;
    }

    // 4. Waterfall sheet ripple
    this.waterfallPlanes.forEach((wf, i) => {
      wf.position.y = 2.4 + Math.sin(elapsed * 5.0 + i) * 0.04;
    });

    // 5. Floating Lotus Water Lanterns current drift and gentle water bobbing
    this.floatingLotusLanterns.forEach((lotus, i) => {
      lotus.position.y = 0.04 + Math.sin(elapsed * 2.2 + i * 1.5) * 0.025;
      lotus.rotation.y = elapsed * 0.15 + i;
    });
  }
}

