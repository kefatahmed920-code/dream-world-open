/**
 * DREAM WORLD — KAIFENG: THE GRAND DYNASTY
 * Standalone Clean Map 3D Environment Project
 * 
 * Features:
 *  - 100% Map Preservation: All 8 districts, 5 major landmarks, 10 interior buildings,
 *    palaces, temples, teahouses, Great Wall mountain fortress, rivers, bridges, docks,
 *    waterfalls, forests, gardens, bamboo, and foliage.
 *  - ZERO Characters / NPCs: Completely clean 3D architectural and natural world.
 *  - ZERO UI / Clutter: Full-screen pure 3D environment.
 *  - Smooth Environmental Orbit, Pan & Zoom Inspection Camera:
 *     * Left-drag / 1-finger touch: Orbit azimuth & elevation
 *     * Right-drag / Shift-drag / 2-finger touch: Pan across the world
 *     * Wheel / Pinch: Zoom from interior detail (2m) to panoramic vista (280m)
 *     * Keyboard (WASD / Arrows / Q / E): Glide camera anywhere across Kaifeng
 *     * Idle cinematic drift: Gentle rotation when idle brings the dynasty to life
 *  - Full Environmental Animations: Flowing water, waving bamboo/willows,
 *    turning waterwheels, swinging bells, dragon barge roll, brazier embers, lake ripples.
 */

import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { TerrainManager } from './terrain';
import { ExpandedDockManager } from './dock';
import { RiverWaterManager } from './water';
import { RockManager } from './rocks';
import { FoliageManager } from './foliage';
import { DhakaCityManager } from './city';
import { AncientBridgeManager } from './bridge';
import { BoatJourneyManager } from './boatJourney';
import { CityEntranceManager } from './cityEntrance';
import { AncientCityManager } from './ancientCity';
import { ChineseHeritageExpansionManager } from './chineseHeritageExpansion';
import { KaifengDynastyManager } from './kaifengGrandDynasty';
import { KaifengArchitectureManager } from './kaifengArchitecture';

export type TimeOfDay = 'day' | 'dusk' | 'dawn';

export class DreamWorldEngine {
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;

  // Standalone Map & Environmental Subsystems (100% Preserved)
  public terrain!: TerrainManager;
  public dock!: ExpandedDockManager;
  public water!: RiverWaterManager;
  public rocks!: RockManager;
  public foliage!: FoliageManager;
  public city!: DhakaCityManager;
  public bridge!: AncientBridgeManager;
  public boatJourney!: BoatJourneyManager;
  public cityEntrance!: CityEntranceManager;
  public ancientCity!: AncientCityManager;
  public chineseHeritage!: ChineseHeritageExpansionManager;
  public kaifengDynasty!: KaifengDynastyManager;
  public kaifengArch!: KaifengArchitectureManager;

  // Lighting & Sky
  private dirLight!: THREE.DirectionalLight;
  private hemiLight!: THREE.HemisphereLight;
  private isSoftwareGl: boolean = false;

  // Environmental Inspection Camera State
  private cameraAzimuth: number = 0.52; // Horizontal angle (radians)
  private cameraElevation: number = 0.38; // Vertical pitch (radians)
  private cameraDistance: number = 65.0; // Distance to target
  private cameraTarget: THREE.Vector3 = new THREE.Vector3(120.0, 10.0, 95.0); // Overlooking Kaifeng Grand Bridge & Bell Tower
  private targetLookAt: THREE.Vector3 = new THREE.Vector3(120.0, 10.0, 95.0);

  // Smooth camera interpolation targets
  private smoothAzimuth: number = 0.52;
  private smoothElevation: number = 0.38;
  private smoothDistance: number = 65.0;

  // Camera Interaction & Idle Motion
  private isInteracting: boolean = false;
  private lastInteractionTime: number = 0;
  private heldKeys: Record<string, boolean> = {};

  // Animation Loop
  private clock: THREE.Clock = new THREE.Clock();
  private frameId: number = 0;
  private isRunning: boolean = false;
  private currentTimeOfDay: TimeOfDay = 'day';

  constructor(private container: HTMLElement) {
    // 1. Software-WebGL Probe
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Scene & Camera Setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color('#D8E5E5');
    this.scene.fog = new THREE.FogExp2('#D8E5E5', 0.0032);

    const width = container.clientWidth || window.innerWidth;
    const height = container.clientHeight || window.innerHeight;
    this.camera = new THREE.PerspectiveCamera(52, width / height, 0.2, 1200);

    // 3. Renderer with PBR Pipeline
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
    });
    this.renderer.setSize(width, height);
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.18;
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;

    container.appendChild(this.renderer.domElement);

    // 4. RoomEnvironment Reflection
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 5. Lighting Setup
    this.setupLighting();

    // 6. Assemble 100% Pure Map & Environmental Systems
    this.initMapEnvironment();

    // 7. Event Listeners & Camera Controls
    window.addEventListener('resize', this.onResize);
    this.setupEnvironmentalCameraControls();
  }

  private setupLighting() {
    // Directional Sunlight highlighting Kaifeng dynasty architecture
    this.dirLight = new THREE.DirectionalLight('#FFF2D4', 1.65);
    this.dirLight.position.set(90, 85, 60);
    this.dirLight.castShadow = !this.isSoftwareGl;
    this.dirLight.shadow.mapSize.width = 1024;
    this.dirLight.shadow.mapSize.height = 1024;
    this.dirLight.shadow.camera.near = 10;
    this.dirLight.shadow.camera.far = 300;
    const d = 95;
    this.dirLight.shadow.camera.left = -d;
    this.dirLight.shadow.camera.right = d;
    this.dirLight.shadow.camera.top = d;
    this.dirLight.shadow.camera.bottom = -d;
    this.dirLight.shadow.bias = -0.0004;
    this.dirLight.shadow.normalBias = 0.02;
    this.scene.add(this.dirLight);

    // Atmospheric Sky / Earth Fill
    this.hemiLight = new THREE.HemisphereLight('#E4EEF2', '#5A6B48', 0.88);
    this.scene.add(this.hemiLight);
  }

  public setTimeOfDay(time: TimeOfDay) {
    this.currentTimeOfDay = time;
    if (time === 'day') {
      this.scene.background = new THREE.Color('#D8E5E5');
      if (this.scene.fog) (this.scene.fog as THREE.FogExp2).color.set('#D8E5E5');
      this.dirLight.color.set('#FFF2D4');
      this.dirLight.intensity = 1.65;
      this.dirLight.position.set(90, 85, 60);
      this.hemiLight.color.set('#E4EEF2');
      this.hemiLight.groundColor.set('#5A6B48');
      this.hemiLight.intensity = 0.88;
    } else if (time === 'dusk') {
      this.scene.background = new THREE.Color('#DCA675');
      if (this.scene.fog) (this.scene.fog as THREE.FogExp2).color.set('#DCA675');
      this.dirLight.color.set('#FF8A3D');
      this.dirLight.intensity = 1.85;
      this.dirLight.position.set(110, 35, 70);
      this.hemiLight.color.set('#E8B084');
      this.hemiLight.groundColor.set('#4A3222');
      this.hemiLight.intensity = 0.72;
    } else if (time === 'dawn') {
      this.scene.background = new THREE.Color('#BAC8D3');
      if (this.scene.fog) (this.scene.fog as THREE.FogExp2).color.set('#BAC8D3');
      this.dirLight.color.set('#FFE8D6');
      this.dirLight.intensity = 1.25;
      this.dirLight.position.set(-60, 40, 30);
      this.hemiLight.color.set('#C8D8E4');
      this.hemiLight.groundColor.set('#3A4B35');
      this.hemiLight.intensity = 0.92;
    }
  }

  public getTimeOfDay(): TimeOfDay {
    return this.currentTimeOfDay;
  }

  /**
   * Initializes 100% of the complete map environment with ZERO characters or NPCs
   */
  private initMapEnvironment() {
    // 1. Natural Terrain, Terraced Rice Paddies & Riverbanks
    this.terrain = new TerrainManager();
    this.scene.add(this.terrain.group);

    // 2. Expanded Wooden Fishing & River Dock
    this.dock = new ExpandedDockManager();
    this.scene.add(this.dock.group);

    // 3. Grand Ancient Chinese Wooden Moon Bridge & Monumental Gateway Pavilions
    this.bridge = new AncientBridgeManager();
    this.scene.add(this.bridge.group);

    // 4. Traditional Environmental River Sampan Boat (floating gently on the river)
    this.boatJourney = new BoatJourneyManager();
    this.scene.add(this.boatJourney.group);

    // 5. River Rocks, Submerged Boulders, & Riverside Mossy Formations
    this.rocks = new RockManager(this.terrain);
    this.scene.add(this.rocks.group);

    // 6. Monumental City Entrance, Boardwalks & Riverside Arrival District
    this.cityEntrance = new CityEntranceManager();
    this.scene.add(this.cityEntrance.group);

    // 7. Dynamic River Water & Rapids Foam
    const combinedFoam = [
      ...this.dock.foamPositions,
      ...this.rocks.submergedRockFoamPositions,
      ...this.bridge.foamPositions,
      ...this.cityEntrance.foamPositions,
    ];
    this.water = new RiverWaterManager(combinedFoam);
    this.scene.add(this.water.group);

    // 8. Natural Foliage (Weeping Willows, Mountain Pines, Bamboo Groves, Reeds)
    this.foliage = new FoliageManager(this.terrain);
    this.scene.add(this.foliage.group);

    // 9. Preserved Southern District Architecture & Houses
    this.city = new DhakaCityManager();
    this.scene.add(this.city.group);

    // 10. Phase 5 Complete Ancient Chinese City (Palaces, Canals, Markets, Outer Farmlands)
    this.ancientCity = new AncientCityManager();
    this.scene.add(this.ancientCity.group);

    // 11. Grand Chinese Heritage Expansion (Karst Mountains, Cloud Hermitage, Great Wall Beacon)
    this.chineseHeritage = new ChineseHeritageExpansionManager();
    this.scene.add(this.chineseHeritage.group);

    // 12. Kaifeng Grand Dynasty (8 Interconnected Districts & Courtyards)
    this.kaifengDynasty = new KaifengDynastyManager();
    this.scene.add(this.kaifengDynasty.group);

    // 13. Complete Chinese Architecture & 5 Major Landmarks (Thousand Bell Tower, Imperial Bridge, Palace, etc.)
    this.kaifengArch = new KaifengArchitectureManager();
    this.scene.add(this.kaifengArch.group);
  }

  /**
   * Smooth Environmental Orbit, Pan & Zoom Camera System
   */
  private setupEnvironmentalCameraControls() {
    let isDragging = false;
    let dragMode: 'orbit' | 'pan' = 'orbit';
    let prevX = 0;
    let prevY = 0;
    let touchDistStart = 0;

    const onPointerDown = (e: MouseEvent) => {
      isDragging = true;
      this.isInteracting = true;
      this.lastInteractionTime = performance.now();
      // Right-click or Shift+Left-click initiates Panning
      if (e.button === 2 || e.shiftKey) {
        dragMode = 'pan';
      } else {
        dragMode = 'orbit';
      }
      prevX = e.clientX;
      prevY = e.clientY;
    };

    const onPointerMove = (e: MouseEvent) => {
      if (!isDragging) return;
      this.isInteracting = true;
      this.lastInteractionTime = performance.now();

      const dx = e.clientX - prevX;
      const dy = e.clientY - prevY;
      prevX = e.clientX;
      prevY = e.clientY;

      if (dragMode === 'orbit') {
        this.cameraAzimuth -= dx * 0.0055;
        this.cameraElevation = Math.max(0.04, Math.min(1.42, this.cameraElevation + dy * 0.0045));
      } else {
        // Pan horizontally relative to current camera azimuth
        const panSpeed = (this.cameraDistance / 80.0) * 0.12;
        const forwardX = -Math.sin(this.cameraAzimuth);
        const forwardZ = -Math.cos(this.cameraAzimuth);
        const rightX = Math.cos(this.cameraAzimuth);
        const rightZ = -Math.sin(this.cameraAzimuth);

        this.cameraTarget.x -= rightX * dx * panSpeed + forwardX * dy * panSpeed;
        this.cameraTarget.z -= rightZ * dx * panSpeed + forwardZ * dy * panSpeed;
      }
    };

    const onPointerUp = () => {
      isDragging = false;
      this.isInteracting = false;
    };

    // Touch Support: 1-finger orbit, 2-finger pan & pinch zoom
    const onTouchStart = (e: TouchEvent) => {
      this.isInteracting = true;
      this.lastInteractionTime = performance.now();

      if (e.touches.length === 1) {
        isDragging = true;
        dragMode = 'orbit';
        prevX = e.touches[0].clientX;
        prevY = e.touches[0].clientY;
      } else if (e.touches.length === 2) {
        isDragging = true;
        dragMode = 'pan';
        prevX = (e.touches[0].clientX + e.touches[1].clientX) * 0.5;
        prevY = (e.touches[0].clientY + e.touches[1].clientY) * 0.5;
        const tdx = e.touches[0].clientX - e.touches[1].clientX;
        const tdy = e.touches[0].clientY - e.touches[1].clientY;
        touchDistStart = Math.hypot(tdx, tdy);
      }
    };

    const onTouchMove = (e: TouchEvent) => {
      if (!isDragging) return;
      this.isInteracting = true;
      this.lastInteractionTime = performance.now();

      if (e.touches.length === 1 && dragMode === 'orbit') {
        const dx = e.touches[0].clientX - prevX;
        const dy = e.touches[0].clientY - prevY;
        prevX = e.touches[0].clientX;
        prevY = e.touches[0].clientY;

        this.cameraAzimuth -= dx * 0.006;
        this.cameraElevation = Math.max(0.04, Math.min(1.42, this.cameraElevation + dy * 0.005));
      } else if (e.touches.length === 2) {
        const curX = (e.touches[0].clientX + e.touches[1].clientX) * 0.5;
        const curY = (e.touches[0].clientY + e.touches[1].clientY) * 0.5;
        const dx = curX - prevX;
        const dy = curY - prevY;
        prevX = curX;
        prevY = curY;

        // Pan
        const panSpeed = (this.cameraDistance / 80.0) * 0.14;
        const forwardX = -Math.sin(this.cameraAzimuth);
        const forwardZ = -Math.cos(this.cameraAzimuth);
        const rightX = Math.cos(this.cameraAzimuth);
        const rightZ = -Math.sin(this.cameraAzimuth);

        this.cameraTarget.x -= rightX * dx * panSpeed + forwardX * dy * panSpeed;
        this.cameraTarget.z -= rightZ * dx * panSpeed + forwardZ * dy * panSpeed;

        // Pinch Zoom
        const tdx = e.touches[0].clientX - e.touches[1].clientX;
        const tdy = e.touches[0].clientY - e.touches[1].clientY;
        const touchDist = Math.hypot(tdx, tdy);
        const pinchDelta = (touchDistStart - touchDist) * 0.25;
        touchDistStart = touchDist;
        this.cameraDistance = Math.max(2.0, Math.min(280.0, this.cameraDistance + pinchDelta));
      }
    };

    const onTouchEnd = () => {
      isDragging = false;
      this.isInteracting = false;
    };

    // Mouse Wheel Zoom
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      this.isInteracting = true;
      this.lastInteractionTime = performance.now();

      const zoomFactor = Math.max(1.0, this.cameraDistance * 0.05);
      const deltaZoom = Math.sign(e.deltaY) * zoomFactor * 2.2;
      this.cameraDistance = Math.max(2.0, Math.min(280.0, this.cameraDistance + deltaZoom));
    };

    // Keyboard Pan Navigation
    const onKeyDown = (e: KeyboardEvent) => {
      this.heldKeys[e.key.toLowerCase()] = true;
      this.lastInteractionTime = performance.now();
      // Time of day toggle with 't'
      if (e.key === 't' || e.key === 'T') {
        const next = this.currentTimeOfDay === 'day' ? 'dusk' : this.currentTimeOfDay === 'dusk' ? 'dawn' : 'day';
        this.setTimeOfDay(next);
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      this.heldKeys[e.key.toLowerCase()] = false;
    };

    // Context Menu override for smooth right-click panning
    const onContextMenu = (e: MouseEvent) => {
      e.preventDefault();
    };

    this.container.addEventListener('mousedown', onPointerDown);
    window.addEventListener('mousemove', onPointerMove);
    window.addEventListener('mouseup', onPointerUp);

    this.container.addEventListener('touchstart', onTouchStart, { passive: true });
    window.addEventListener('touchmove', onTouchMove, { passive: true });
    window.addEventListener('touchend', onTouchEnd);

    this.container.addEventListener('wheel', onWheel, { passive: false });
    this.container.addEventListener('contextmenu', onContextMenu);

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
  }

  private updateKeyboardNavigation(delta: number) {
    const keys = this.heldKeys;
    let forward = 0;
    let right = 0;
    let up = 0;

    if (keys['w'] || keys['arrowup']) forward += 1;
    if (keys['s'] || keys['arrowdown']) forward -= 1;
    if (keys['d'] || keys['arrowright']) right += 1;
    if (keys['a'] || keys['arrowleft']) right -= 1;
    if (keys['e'] || keys[' ']) up += 1;
    if (keys['q'] || keys['c']) up -= 1;

    if (forward !== 0 || right !== 0 || up !== 0) {
      this.lastInteractionTime = performance.now();
      const moveSpeed = (this.cameraDistance * 0.45 + 15.0) * delta;

      const forwardX = -Math.sin(this.cameraAzimuth);
      const forwardZ = -Math.cos(this.cameraAzimuth);
      const rightX = Math.cos(this.cameraAzimuth);
      const rightZ = -Math.sin(this.cameraAzimuth);

      this.cameraTarget.x += (forwardX * forward + rightX * right) * moveSpeed;
      this.cameraTarget.z += (forwardZ * forward + rightZ * right) * moveSpeed;
      this.cameraTarget.y = Math.max(0.5, Math.min(180.0, this.cameraTarget.y + up * moveSpeed * 0.65));
    }
  }

  private onResize = () => {
    if (!this.container) return;
    const width = this.container.clientWidth || window.innerWidth;
    const height = this.container.clientHeight || window.innerHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  /**
   * Software-WebGL Paced afterDraw mechanism
   */
  private afterDraw(cb: () => void) {
    const gl = this.renderer.getContext() as WebGL2RenderingContext;
    const sync = gl.fenceSync(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
    gl.flush();
    const poll = () => {
      const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
      if (state === gl.UNSIGNALED) {
        this.frameId = window.setTimeout(poll, 4);
      } else {
        if (sync) gl.deleteSync(sync);
        this.frameId = window.setTimeout(cb, 16);
      }
    };
    this.frameId = window.setTimeout(poll, 4);
  }

  /**
   * Main Standalone Map Simulation Loop
   */
  public start() {
    this.isRunning = true;
    this.clock.start();

    const tick = () => {
      if (!this.isRunning) return;

      const rawDt = this.clock.getDelta();
      const delta = Math.min(rawDt, 0.05);
      const elapsed = this.clock.getElapsedTime();

      // 1. Keyboard Map Navigation
      this.updateKeyboardNavigation(delta);

      // 2. Idle Cinematic Drift (Slow majestic rotation when user is idle for > 2.5s)
      const now = performance.now();
      if (!this.isInteracting && now - this.lastInteractionTime > 2500) {
        this.cameraAzimuth += delta * 0.022; // ~1.2 deg/sec gentle orbit
      }

      // 3. Smooth Camera Damping
      this.smoothAzimuth = THREE.MathUtils.damp(this.smoothAzimuth, this.cameraAzimuth, 10, delta);
      this.smoothElevation = THREE.MathUtils.damp(this.smoothElevation, this.cameraElevation, 10, delta);
      this.smoothDistance = THREE.MathUtils.damp(this.smoothDistance, this.cameraDistance, 10, delta);

      this.targetLookAt.x = THREE.MathUtils.damp(this.targetLookAt.x, this.cameraTarget.x, 9, delta);
      this.targetLookAt.y = THREE.MathUtils.damp(this.targetLookAt.y, this.cameraTarget.y, 9, delta);
      this.targetLookAt.z = THREE.MathUtils.damp(this.targetLookAt.z, this.cameraTarget.z, 9, delta);

      const camX = this.targetLookAt.x + Math.sin(this.smoothAzimuth) * Math.cos(this.smoothElevation) * this.smoothDistance;
      const camY = this.targetLookAt.y + Math.sin(this.smoothElevation) * this.smoothDistance;
      const camZ = this.targetLookAt.z + Math.cos(this.smoothAzimuth) * Math.cos(this.smoothElevation) * this.smoothDistance;

      this.camera.position.set(camX, camY, camZ);
      this.camera.lookAt(this.targetLookAt);

      // Sunlight follows camera focus point
      this.dirLight.position.set(
        this.targetLookAt.x + 60,
        85,
        this.targetLookAt.z + 45
      );
      this.dirLight.target.position.copy(this.targetLookAt);
      this.dirLight.target.updateMatrixWorld();

      // 4. Update Environmental Dynamic Systems
      this.water.update(delta, elapsed);
      this.foliage.update(delta, elapsed);
      this.boatJourney.update(delta, elapsed);
      this.ancientCity.update(delta, elapsed);
      this.chineseHeritage.update(delta, elapsed);
      this.kaifengDynasty.update(delta, elapsed);
      this.kaifengArch.update(delta, elapsed);

      // 5. Render Scene
      this.renderer.render(this.scene, this.camera);

      // 6. Next Frame
      if (this.isSoftwareGl) {
        this.afterDraw(tick);
      } else {
        this.frameId = requestAnimationFrame(tick);
      }
    };

    if (this.isSoftwareGl) {
      this.afterDraw(tick);
    } else {
      this.frameId = requestAnimationFrame(tick);
    }
  }

  public stop() {
    this.isRunning = false;
    cancelAnimationFrame(this.frameId);
    clearTimeout(this.frameId);
  }

  public dispose() {
    this.stop();
    window.removeEventListener('resize', this.onResize);
    this.renderer.dispose();
    if (this.renderer.domElement.parentElement) {
      this.renderer.domElement.parentElement.removeChild(this.renderer.domElement);
    }
  }
}
