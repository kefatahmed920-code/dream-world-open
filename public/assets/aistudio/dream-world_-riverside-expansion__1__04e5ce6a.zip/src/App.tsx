/**
 * DREAM WORLD — KAIFENG: THE GRAND DYNASTY
 * Standalone Clean Map 3D Environment Project
 * 
 * 100% Full-Screen Pure 3D Environment View
 * - Zero Characters / NPCs
 * - Zero UI / Zero Text / Zero Overlays
 * - Full interactive 3D inspection camera (Orbit, Pan, Zoom)
 */

import React, { useEffect, useRef } from 'react';
import { DreamWorldEngine } from './game/scene';
import { soundEngine } from './game/audio';

export default function App() {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<DreamWorldEngine | null>(null);

  useEffect(() => {
    if (!containerRef.current) return;

    // Initialize standalone 3D map engine
    const engine = new DreamWorldEngine(containerRef.current);
    engineRef.current = engine;

    // Start engine loop
    engine.start();

    // Gentle ambient audio on first gesture
    const handleFirstGesture = () => {
      soundEngine.resume();
      window.removeEventListener('pointerdown', handleFirstGesture);
      window.removeEventListener('keydown', handleFirstGesture);
    };
    window.addEventListener('pointerdown', handleFirstGesture);
    window.addEventListener('keydown', handleFirstGesture);

    return () => {
      window.removeEventListener('pointerdown', handleFirstGesture);
      window.removeEventListener('keydown', handleFirstGesture);
      engine.dispose();
      engineRef.current = null;
    };
  }, []);

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-[#101416] select-none">
      {/* 100% Full-Screen Pristine 3D WebGL Canvas */}
      <div ref={containerRef} className="absolute inset-0 w-full h-full cursor-grab active:cursor-grabbing" />
    </div>
  );
}
