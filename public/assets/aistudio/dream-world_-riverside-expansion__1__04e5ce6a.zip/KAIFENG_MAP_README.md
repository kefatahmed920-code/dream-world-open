# DREAM WORLD — KAIFENG: THE GRAND DYNASTY
## Standalone 3D Environment Project & Clean Map Export

This package contains the complete, standalone 3D environment for **Kaifeng: The Grand Dynasty** — an expansive, interconnected Chinese historical open-world map inspired by Northern Song Dynasty Kaifeng, Jiangnan water towns, imperial palace courtyards, classical scholar gardens, karst mountain peaks, and Great Wall mountain fortifications.

---

### 1. MAP SPECIFICATIONS & KEY DISTRICTS

The Kaifeng world spans over **320m × 220m** of continuous, fully rendered, interconnected 3D terrain:

1. **District 1: Grand Southern Gate & Arrival Courtyard** `(Z: 20 to 60)`
   - Triple-portal monumental fortress gate, flag banners, stone guardian lions, stone-paved processional road.
2. **District 2: Eastern Waterfront & Jiangnan Water Town** `(X: 130 to 190, Z: 50 to 140)`
   - White plaster & black tile riverside residences, wooden balconies overhanging canals, stone steps leading into the water, arched footbridges, floating lotus lanterns.
3. **District 3: Central Commercial Market & Artisan Guilds** `(X: 70 to 130, Z: 60 to 130)`
   - 2-story wooden merchant shops, colorful dyed silk fabric banners, lanterns, food stalls, pottery workshops, bronze cauldrons.
4. **District 4: Western Classical Scholars' Garden** `(X: 20 to 70, Z: 60 to 140)`
   - Moon gates, covered winding corridors (*lang*), koi ponds with wooden zig-zag bridges, bamboo groves, stone scholar's rocks (*taihu*), open tea pavilions.
5. **District 5: Imperial Palace of Supreme Harmony (*Taihe Dian*)** `(X: 80 to 160, Z: 130 to 200)`
   - Multi-tier white marble terraces with carved dragon balustrades, imperial golden-glazed tiled hipped roofs, towering lacquered vermilion columns, grand throne hall.
6. **District 6: Northern Karst Mountains & Cloud Temple** `(X: 20 to 100, Z: 190 to 280)`
   - Dramatic mist-shrouded limestone karst peaks rising to 45m elevation, stone mountain stairways, Daoist mountain hermitage with incense burners and prayer bell.
7. **District 7: Heavenly Waterfall Basin & Serene Lake** `(X: 100 to 170, Z: 200 to 270)`
   - 35m multi-tier cascading waterfall with translucent water sheets, spray foam particles, emerald mountain lake, waterwheel mechanism.
8. **District 8: Northern Mountain Fortress & Great Wall Ramparts** `(X: 30 to 190, Z: 260 to 320)`
   - High stone mountain ridge battlements, crenellated parapets, two-story stone watchtowers, beacon fire braziers, arched fortress gates, mountain pass defense.

---

### 2. CORE LANDMARKS & COORDINATES

| Landmark | Coordinates (X, Y, Z) | Description |
| :--- | :--- | :--- |
| **Thousand Bell Tower (*Qianling*)** | `(148.0, 0.0, 78.0)` | 4-tier octagonal pagoda tower with 32 swinging bronze wind-bells and octagonal balustrades. |
| **Imperial Grand Moon Bridge** | `(120.0, 0.0, 0.0)` | Monumental arched stone & timber bridge crossing the Grand River with gateway roof pavilions. |
| **Royal Palace Taihe Hall** | `(120.0, 3.8, 168.0)` | Grand imperial palace hall on a 3-tier white marble terrace with carved dragon balustrades. |
| **Heavenly Waterfall Basin** | `(138.0, 4.0, 238.0)` | 35m cliff waterfall feeding into an emerald mist lake with turning timber waterwheel. |
| **Golden River Market & Dragon Barge**| `(152.0, 0.0, 105.0)` | Waterfront trading hub with moored 18m ornamental imperial dragon barge on river canal. |

---

### 3. ACCESSIBLE ENTERABLE BUILDINGS (Double-Wall 3D Architecture)

All 10 accessible buildings feature real 3D double-walled construction, framed door and window openings, timber floorboards, and complete interior furnishings:

1. **Riverside Tea House "Pavilion of Mist"** `(138.0, 0.0, 68.0)`
   - Tea tables, porcelain tea sets, calligraphy scrolls, low cushions, carved privacy screens.
2. **Grand Two-Story Silk Merchant Guild** `(102.0, 0.0, 78.0)`
   - Bolts of silk, merchant counters, abacus, display shelves, upstairs sleeping quarters.
3. **Herbalist Apothecary & Medicine Hall** `(88.0, 0.0, 92.0)`
   - Wall of 48 wooden medicine herb drawers, brass mortar and pestle, hanging dried herbs.
4. **Master Calligrapher's Courtyard Studio** `(52.0, 0.0, 85.0)`
   - Large wooden writing desk, inkstones, brush racks with animal hair brushes, rice paper scrolls.
5. **Imperial Wine Tavern "Moonlit Lotus"** `(144.0, 0.0, 116.0)`
   - Ceramic wine jars, wooden dining benches, serving counter, balcony overlooking canal.
6. **Daoist Meditation Hall "White Cloud Hermitage"** `(58.0, 24.0, 218.0)`
   - Meditation cushions, incense brazier with smoke effect, bagua trigram banner, mountain cliff view.
7. **Scholar's Classical Garden Pavilion** `(45.0, 0.0, 125.0)`
   - Hexagonal open pavilion, stone table with carved stools, guqin string instrument, pond view.
8. **Northern Mountain Watchpost Barracks** `(165.0, 35.0, 290.0)`
   - Wooden bunk beds, weapon racks with spears and dao blades, stone fireplace, patrol maps.
9. **Great Wall Commander's High Bastion** `(118.0, 48.0, 310.0)`
   - Commander's war map table, iron lanterns, signal fire brazier, panoramic vantage point.
10. **Waterfront Artisan Woodcarver Workshop** `(162.0, 0.0, 92.0)`
    - Woodworking workbench, carpenter tools, wooden timber blocks, river access landing.

---

### 4. ENVIRONMENTAL SYSTEMS & ANIMATIONS

- **Dynamic Water Shaders**: Flowing river currents, normal map ripples, foam at bridge piers and dock pilings, depth attenuation, translucent waterfall sheets.
- **Foliage & Bamboo**: Multi-tier wind animation on weeping willows, mountain pines, bamboo groves, and riverbank reeds.
- **Dynasty Animations**: Swaying silk fabric banners, swinging bronze pagoda bells, glowing lanterns, turning waterwheel, floating dragon barge bobbing, flickering braziers.
- **Lighting Pipeline**:
  - PBR standard pipeline with `RoomEnvironment` PMREM reflections.
  - Three distinct lighting modes: Daylight (`day`), Golden Dusk (`dusk`), Misty Dawn (`dawn`).
  - `ACESFilmicToneMapping` with exposure 1.18 and `SRGBColorSpace`.

---

### 5. HOW TO IMPORT INTO YOUR DREAM WORLD PROJECT

1. **Copy the Source Files**:
   - Extract `src/game/` into your project's `src/game/` directory.
   - Core map files:
     - `src/game/scene.ts`: World engine, camera management, rendering loop.
     - `src/game/terrain.ts`: Heightmap, riverbed carving, terraced slopes.
     - `src/game/kaifengGrandDynasty.ts`: 8 master districts, grand avenues, courtyards.
     - `src/game/kaifengArchitecture.ts`: 5 major landmarks, 10 accessible furnished buildings.
     - `src/game/water.ts`: Realistic river and canal water mesh.
     - `src/game/foliage.ts`: Procedural trees, bamboo groves, willows, reeds.
     - `src/game/textures.ts`: High-res procedural canvas textures (roof tiles, wood, stone, plaster).
     - `src/game/rocks.ts`: Riverside boulders, cliffs, and karst rock formations.
     - `src/game/bridge.ts`: Grand wooden moon bridge.
     - `src/game/dock.ts`: Wooden river docks and slips.
     - `src/game/cityEntrance.ts`: Southern gateway fortress entrance.
     - `src/game/city.ts`: Preserved southern riverside houses.
     - `src/game/ancientCity.ts`: Ancient city core and canal infrastructure.
     - `src/game/chineseHeritageExpansion.ts`: Karst mountains and Great Wall fortress.

2. **Mounting the Scene in React / Three.js**:
   ```typescript
   import { DreamWorldEngine } from './game/scene';

   const container = document.getElementById('canvas-container');
   const engine = new DreamWorldEngine(container);
   engine.start();
   ```

3. **Collision Detection Integration**:
   Every building and terrain feature contains built-in spatial collision bounds:
   ```typescript
   // Check terrain height
   const y = engine.terrain.getTerrainHeight(x, z);

   // Check building collision (10 accessible buildings with internal rooms)
   const hit = engine.kaifengArch.checkBuildingCollision(x, z, playerRadius);
   ```

4. **Camera Controls**:
   The standalone map includes a smooth Orbit, Pan & Zoom inspection camera:
   - **Left Click Drag / Touch 1 Finger**: Orbit view around focus target.
   - **Right Click Drag / Shift + Drag / Touch 2 Fingers**: Pan camera across the map.
   - **Mouse Wheel / Pinch**: Zoom in/out (from 2m close-up to 280m panoramic view).
   - **WASD / Arrow Keys**: Glide camera across the world horizontally.
   - **Q / E Keys**: Adjust camera elevation up / down.
   - **Idle Drift**: Automatically initiates gentle cinematic orbit after 2.5s of inactivity.
